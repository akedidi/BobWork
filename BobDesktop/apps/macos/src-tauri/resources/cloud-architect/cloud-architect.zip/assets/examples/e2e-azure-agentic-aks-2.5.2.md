# Prompt E2E strict — Azure Agentic AI on AKS

Génère depuis zéro le master exécutif « Azure Agentic AI on AKS ». Ne lis, ne copie et ne réutilise aucun ancien fichier `architecture.*`, SVG, PNG, D2, DOT ni dossier `legacy-auto-layout`. Le résultat doit être produit par Bob avec le plugin Cloud Architect actif.

Avant de commencer, exécute ce préflight bloquant :

1. Confirme que la version active du plugin est exactement 2.5.2. Si ce n’est pas 2.5.2, signale l’écart puis arrête-toi immédiatement.
2. Vérifie D2 0.7.1, Mermaid 11.17.1, PlantUML 1.2026.4, C4-PlantUML 2.13.0 et le catalogue local d’au moins 1 959 icônes officielles : AWS ≥ 935, Azure ≥ 714, GCP ≥ 45 et IBM Cloud ≥ 265. Si une vérification échoue, signale-la puis arrête-toi immédiatement.
3. Crée un nouveau dossier de sortie nommé `bob-e2e-azure-agentic-aks`.

Crée `architecture.json` avec `name: Azure Agentic AI on AKS`, `version: 1.0.0`, `status: proposed`, le provider Azure en région West Europe, et l’objectif suivant : solution d’IA agentique sur AKS, accès PaaS privés, GitOps, identité managée et observabilité.

Le master doit contenir exactement ces 19 composants et identifiants :

- `user` — Clients & Applications — acteur générique
- `app-gateway` — Application Gateway + WAF — Azure Application Gateway
- `apim` — Azure API Management
- `apim-gw-aks` — APIM self-hosted gateway dans AKS
- `orchestrator` — Agent Orchestrator — hub d’orchestration technique, jamais un visage
- `tool-agents` — Specialized Tool Agents
- `azure-openai` — Azure OpenAI Service
- `ai-search` — Azure AI Search RAG
- `cosmos-db` — Cosmos DB
- `redis` — Azure Cache for Redis
- `key-vault` — Key Vault
- `event-hubs` — Event Hubs
- `git-repo` — Git Repository
- `flux-cd` — Flux v2
- `acr` — Azure Container Registry
- `entra-id` — Microsoft Entra ID
- `prometheus` — Prometheus + Grafana
- `otel-collector` — OpenTelemetry Collector
- `azure-monitor` — Azure Monitor + Log Analytics

Utilise exactement ces 16 flux : `user -> app-gateway: HTTPS 443`; `app-gateway -> apim: WAF-filtered`; `apim -> apim-gw-aks: Private ingress`; `apim-gw-aks -> orchestrator: mTLS`; `orchestrator -> tool-agents: Tool dispatch`; `orchestrator -> azure-openai: LLM completion`; `tool-agents -> ai-search: RAG query`; `orchestrator -> cosmos-db: Session memory`; `orchestrator -> redis: Response cache`; `orchestrator -> key-vault: Managed identity`; `orchestrator -> event-hubs: Audit events`; `git-repo -> flux-cd: GitOps`; `flux-cd -> acr: OCI artifacts`; `entra-id -> orchestrator: Workload identity`; `prometheus -> otel-collector: Metrics`; `otel-collector -> azure-monitor: OTLP`.

Rendu obligatoire : utilise `scripts/render_professional_svg.py`; master 1920 × 1080, paysage 16:9, lecture gauche vers droite ; zones Consumers, Secure ingress, AKS — agent runtime, Azure AI, Private data services et Cross-cutting platform capabilities. Utilise les icônes Azure officielles pour les services Azure et les pictogrammes techniques sémantiques v2 pour les composants génériques. Interdiction absolue d’emoji, smiley, visage, mascotte, avatar Bob, robot décoratif ou pictogramme sans rapport avec la fonction. Les icônes doivent être locales et embarquées dans le SVG, sans hotlink. Ne remplace jamais un type générique par une icône de produit cloud ; en cas d’ambiguïté, échoue explicitement.

Livre `architecture.json`, `architecture.svg`, `architecture.png`, `architecture.executive.model.json` et `architecture.delivery.json`. Exécute `qa_professional_svg.py`, inspecte visuellement le SVG à 100 % puis le PNG en 1920 × 1080, et corrige tout chevauchement, texte tronqué, connecteur traversant une carte ou icône incorrecte.

À la fin, annonce : 19 composants, 16 flux, 19 icônes, QA PASS, aucune icône faciale ou emoji, aucune ressource externe. Donne les chemins absolus de tous les fichiers générés, enregistre-les comme artefacts Bob Work et intègre le PNG dans la réponse avec `![Azure Agentic AI on AKS](</chemin/absolu/architecture.png>)`. Une simple liste de chemins sans aperçu visible est un échec de livraison.

`@plugin:agentic-cloud-architect`
