# Diagram engine matrix

Use the smallest professional notation that communicates the requested concern. Do not force every concern into a cloud topology.

| Requested view | Normalized `diagram.type` | Authoritative engine | Editable source |
|---|---|---|---|
| Cloud, network, Kubernetes, deployment topology | `cloud-topology` or the architecture model | D2 0.7.1 + ELK | `.d2` |
| Flow, workflow, process map | `flowchart` or `workflow` | Mermaid 11.17.1 | `.mmd` |
| Interaction timeline | `sequence` | Mermaid 11.17.1 | `.mmd` |
| Lifecycle or status machine | `state` | Mermaid 11.17.1 | `.mmd` |
| User/platform journey | `journey` | Mermaid 11.17.1 | `.mmd` |
| C4 system context | `c4-context` | PlantUML 1.2026.4 + C4 stdlib 2.13.0 | `.puml` |
| C4 container | `c4-container` | PlantUML 1.2026.4 + C4 stdlib 2.13.0 | `.puml` |
| C4 component | `c4-component` | PlantUML 1.2026.4 + C4 stdlib 2.13.0 | `.puml` |
| C4 numbered interaction flow | `c4-dynamic` | PlantUML 1.2026.4 + C4 stdlib 2.13.0 | `.puml` |
| C4 infrastructure/deployment view | `c4-deployment` | PlantUML 1.2026.4 + C4 stdlib 2.13.0 | `.puml` |
| Formal class, component, deployment, activity, use-case, sequence, or state UML | `uml-*` | PlantUML 1.2026.4 | `.puml` |

## Mandatory execution

1. Create or update the normalized JSON model. Validate it with `scripts/validate_diagram_model.py` unless it is the existing architecture-model format used by D2.
2. Run `scripts/render_diagram.py MODEL --output-dir DIRECTORY`. This generates the editable source, authoritative SVG, PNG preview, and a delivery record.
3. Run the generated SVG through `scripts/qa_diagram.py`; the router does this automatically.
4. Inspect the SVG and PNG visually. Regenerate if text, connectors, canvas ratio, grouping, or hierarchy is not professional.
5. Deliver the editable source and both visual formats. A source-only Mermaid or PlantUML answer is incomplete.

The Mermaid bundle is rendered locally through headless Chrome and never loads code or assets from a CDN. PlantUML and its C4 standard library are contained in the pinned JAR and render without Internet access.

C4 deployment models may nest cloud, region, availability-zone, network, subnet, Kubernetes cluster, and namespace boundaries. C4 context/container/component/dynamic/deployment elements may reference managed AWS, Azure, GCP, or IBM icon keys. Their official SVG artwork is converted locally to a fixed 48 px lossless derivative and embedded in both delivery formats; no CDN or external URL is used.

Run the complete regression matrix with `python3 scripts/smoke_test_diagram_engines.py --output-dir <folder>`. It renders and QA-checks D2/ELK, five Mermaid types, seven UML types, and five C4 types, then writes `matrix-report.json` and `matrix-report.md`.
