# Bob Work professional cloud diagram policy

This adapter policy strengthens the upstream Cloud Architecture Diagrams workflow for Bob Work.

## Mandatory output strategy

1. Treat the architecture model as the source of truth.
2. For any provider-specific diagram, resolve managed local SVG icons from `assets/icon-manifest.json`. Never use emoji, Unicode pictograms, text glyphs, faces, mascots, or assistant avatars as substitutes for technical service icons.
3. Use the official provider icon for a named provider service and a semantically matched neutral technical icon for provider-independent concepts. A generic database, cache, queue, API, compute service, network, identity service, secret store, registry, search engine, or storage service must never inherit an Azure, AWS, Google Cloud, or IBM product icon merely from its type. Agents use an orchestration topology symbol, never a face.
4. Generate an editable D2/ELK technical view with `scripts/generate_professional_d2.py`. The script copies every selected icon into the deliverable folder so the D2 source remains portable.
5. When the model contains more than 18 components, produce at least:
   - an executive overview;
   - a deployment or network view;
   - an operations view when delivery, identity, or observability relationships are present.
6. A screen-sized master view may contain at most 20 visible components and must pass a 3:1 aspect-ratio limit. The delivered master `architecture.svg` / `architecture.png` MUST be produced with `$HOME/.bob/skills/cloud-architect/scripts/render_professional_svg.py` (official icons, deterministic layout). Never shadow that script in the workspace. Retain D2 for detailed companion views only. A structurally valid but visually tangled auto-layout is not an acceptable master. Never invent a freestyle SVG generator as the primary path; freestyle is allowed only after `render_professional_svg.py` fails for a documented reason.
7. Render technical companion SVG with the bundled D2 runtime, which embeds all local icons. PNG is a convenience export; SVG remains authoritative.
8. Run `scripts/qa_professional_svg.py --master` against the screen master and the normal command against each view-specific model. An extreme aspect ratio, a missing icon, an emoji icon substitute, an external image hotlink, or a model-count mismatch is a blocking failure.
9. Inspect the full-size SVG and a delivery-size 1920 px raster. Do not deliver a diagram with a connector through a card, overlapping labels, unreadable text, or an accidental portrait/ultra-wide canvas.
10. Use large, visibly bounded functional zones with distinct low-contrast fills. Keep cards fully inside their zones, align peers to a shared grid, and preserve at least 24 px of clear internal padding around zone contents at delivery size.
11. Route the primary request path in one uninterrupted lane. Put identity, delivery, observability, private-link and asynchronous flows in separate bands or connector gutters; never weave them through the primary component row.
12. If a single view cannot keep every connector traceable at delivery size, reduce the master to the decision story and generate named deployment/network and operations companion views. Do not shrink labels or expand to an ultra-wide canvas to retain all edges.

## Multi-notation routing

- D2/ELK is authoritative for cloud, network, Kubernetes, and deployment topologies where official provider icons communicate component identity.
- Mermaid is authoritative for flowcharts, workflows, sequences, state machines, and journeys. It is bundled locally, rendered without CDN access, and must use a solid delivery background.
- Mermaid labels must use native SVG text wherever supported. PNG export is captured by the same local browser renderer so journey labels remain identical; Mermaid journey faces are replaced by neutral numeric score badges before delivery.
- PlantUML is authoritative for formal UML and dedicated C4 context/container/component/dynamic/deployment views. C4 includes must come from the standard library embedded in the pinned PlantUML JAR. C4 deployment boundaries must represent cloud, region, network and Kubernetes nesting explicitly; managed provider icons are allowed when they improve service identification.
- A C4/UML/sequence/flow/state diagram does not require provider icons on every element. Use the notation's standard semantic shapes; never inject cloud icons where they reduce correctness.
- Run `scripts/render_diagram.py` for normalized diagram models. Source-only output, an unrendered fenced code block, or a render without SVG+PNG+QA is not a completed diagram delivery.

## Icon provenance

- Microsoft Azure assets come from the official Azure Architecture Center V24 SVG archive.
- The archive URL, retrieval date, terms note, per-file paths, and SHA-256 checksums are recorded in `assets/icon-manifest.json`.
- Provider icons must not be recolored, rotated, cropped, stretched, or used to represent a different product.
- Final SVG artifacts must embed icons locally and must not hotlink remote assets.

## Required inspection record

Record the target canvas, view purpose, reading direction, visible component/relationship/icon counts, structural QA result, visual inspection result, and whether the master switched from D2 auto-layout to deterministic fixed layout.
