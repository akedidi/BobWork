#!/usr/bin/env python3
"""Search the managed official icon catalog and return stable model icon keys."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


PLUGIN_ROOT = Path(__file__).resolve().parent.parent


def load_generator():
    path = PLUGIN_ROOT / "scripts" / "generate_professional_d2.py"
    spec = importlib.util.spec_from_file_location("cloud_architect_generator", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("provider", choices=("aws", "azure", "gcp", "ibm"))
    parser.add_argument("query")
    parser.add_argument("--limit", type=int, default=10)
    args = parser.parse_args()

    generator = load_generator()
    catalog = generator.icon_catalog()
    component = {
        "id": args.query,
        "label": args.query,
        "service": args.query,
        "provider": args.provider,
    }
    component = generator.canonical_service_component(component, args.provider)
    ranked = sorted(
        (
            (generator.provider_icon_score(component, asset), key, asset)
            for key, asset in catalog.items()
            if asset.get("provider") == args.provider
        ),
        key=lambda item: (-item[0], item[2].get("displayName", ""), item[1]),
    )
    results = [
        {
            "score": score,
            "key": key,
            "name": asset.get("displayName"),
            "category": asset.get("category"),
            "sourcePath": asset.get("sourcePath"),
        }
        for score, key, asset in ranked[: max(1, args.limit)]
        if score > 0
    ]
    print(json.dumps(results, ensure_ascii=False, indent=2))
    return 0 if results else 1


if __name__ == "__main__":
    raise SystemExit(main())
