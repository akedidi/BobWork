#!/usr/bin/env python3
"""Perform structural QA on an SVG diagram before human visual inspection."""

from __future__ import annotations

import argparse
import json
import math
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("svg", type=Path)
    parser.add_argument("--model", type=Path)
    parser.add_argument("--max-aspect-ratio", type=float, default=3.0)
    parser.add_argument("--min-font-size", type=float, default=12.0)
    parser.add_argument(
        "--wall-sized",
        action="store_true",
        help="Allow an intentionally wall-sized canvas beyond the normal aspect-ratio gate",
    )
    parser.add_argument(
        "--allow-missing-icons",
        action="store_true",
        help="Do not fail when icon-backed model components have no rendered image",
    )
    args = parser.parse_args()

    errors: list[str] = []
    warnings: list[str] = []
    try:
        root = ET.parse(args.svg).getroot()
    except (OSError, ET.ParseError) as exc:
        print(f"ERROR: {exc}")
        return 1

    view_box = root.attrib.get("viewBox", "").split()
    width = height = 0.0
    if len(view_box) != 4:
        errors.append("SVG has no valid viewBox")
    else:
        try:
            width = float(view_box[2])
            height = float(view_box[3])
            if width <= 0 or height <= 0:
                errors.append("SVG viewBox has non-positive dimensions")
            elif max(width / height, height / width) > args.max_aspect_ratio:
                message = (
                    f"SVG aspect ratio {width / height:.2f}:1 exceeds the configured "
                    "screen-delivery threshold"
                )
                if args.wall_sized:
                    warnings.append(message)
                else:
                    errors.append(message)
        except ValueError:
            errors.append("SVG viewBox dimensions are not numeric")

    groups = list(root.iter("{http://www.w3.org/2000/svg}g"))
    node_count = sum("node" in group.attrib.get("class", "").split() for group in groups)
    edge_count = sum("edge" in group.attrib.get("class", "").split() for group in groups)
    if node_count == 0:
        node_count = sum(bool(group.attrib.get("id")) for group in groups)
    if edge_count == 0:
        edge_count = sum(
            bool(element.attrib.get("marker-end"))
            for element in root.iter("{http://www.w3.org/2000/svg}path")
        )
    if node_count == 0:
        errors.append("SVG contains no recognized nodes")
    if edge_count == 0:
        warnings.append("SVG contains no recognized edges")

    ids = [element.attrib["id"] for element in root.iter() if "id" in element.attrib]
    if len(ids) != len(set(ids)):
        errors.append("SVG contains duplicate id attributes")

    href_keys = ("href", "{http://www.w3.org/1999/xlink}href")
    image_count = 0
    for element in root.iter():
        if element.tag == "{http://www.w3.org/2000/svg}image":
            image_count += 1
        for key in href_keys:
            href = element.attrib.get(key, "")
            if href.startswith(("http://", "https://")):
                errors.append(f"SVG hotlinks an external asset: {href}")

    for element in root.iter("{http://www.w3.org/2000/svg}text"):
        rendered_text = "".join(element.itertext()).strip()
        if any(
            ord(character) >= 0x1F000
            for character in rendered_text
        ):
            errors.append(
                f"emoji is used as an icon substitute instead of a managed SVG asset: {rendered_text}"
            )
        if "…" in rendered_text or rendered_text.endswith("..."):
            warnings.append(f"text may be truncated with ellipsis: {rendered_text}")
        font_size = element.attrib.get("font-size")
        if args.min_font_size and font_size:
            try:
                numeric_size = float(font_size.removesuffix("px").removesuffix("pt"))
                if math.isfinite(numeric_size) and numeric_size < args.min_font_size:
                    warnings.append(
                        f"text font-size {numeric_size:g} is below configured minimum {args.min_font_size:g}: {rendered_text}"
                    )
            except ValueError:
                warnings.append(f"could not evaluate font-size {font_size!r}: {rendered_text}")

    if args.model:
        payload = json.loads(args.model.read_text(encoding="utf-8"))["architecture"]
        expected_nodes = len(payload.get("components", []))
        expected_edges = len(payload.get("relationships", []))
        if node_count != expected_nodes:
            errors.append(f"node count {node_count} does not match model count {expected_nodes}")
        if edge_count != expected_edges:
            errors.append(f"edge count {edge_count} does not match model count {expected_edges}")
        expected_icons = sum(
            bool(component.get("icon")) for component in payload.get("components", [])
        )
        if (
            expected_icons
            and image_count < expected_icons
            and not args.allow_missing_icons
        ):
            errors.append(
                f"rendered icon count {image_count} is below model requirement {expected_icons}"
            )

    for error in errors:
        print(f"ERROR: {error}")
    for warning in warnings:
        print(f"WARNING: {warning}")
    print(
        f"RESULT: {'PASS' if not errors else 'FAIL'} "
        f"({node_count} nodes, {edge_count} edges, {image_count} icons)"
    )
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
