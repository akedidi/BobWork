#!/usr/bin/env python3
"""Import and index complete official AWS, Azure, GCP, and IBM SVG catalogs."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable
from xml.etree import ElementTree


PLUGIN_ROOT = Path(__file__).resolve().parent.parent
ASSET_ROOT = PLUGIN_ROOT / "assets"
MANIFEST_PATH = ASSET_ROOT / "icon-manifest.json"
MANAGED_COLLECTION_PREFIX = "official-full-"


@dataclass(frozen=True)
class Candidate:
    provider: str
    source_path: str
    payload: bytes
    collection: str


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def slug(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]+", "-", ascii_value.lower()).strip("-")


def display_name(source_path: str) -> str:
    stem = PurePosixPath(source_path).stem
    stem = re.sub(r"^(?:arch|res|category|icon)[_-]+", "", stem, flags=re.I)
    stem = re.sub(r"^\d+-icon-service-", "", stem, flags=re.I)
    stem = re.sub(r"[-_](?:16|24|32|48|64|128|256|512)(?:-color-rgb)?$", "", stem, flags=re.I)
    stem = re.sub(r"[-_](?:dark|light)$", "", stem, flags=re.I)
    return re.sub(r"[_-]+", " ", stem).strip()


def aliases(source_path: str) -> list[str]:
    name = display_name(source_path)
    values = {name, slug(name), PurePosixPath(source_path).stem}
    for prefix in ("Amazon ", "AWS ", "Azure ", "Google Cloud ", "Cloud ", "IBM Cloud "):
        if name.lower().startswith(prefix.lower()):
            values.add(name[len(prefix):])
    return sorted(value for value in values if value)


def valid_svg(payload: bytes, source_path: str) -> None:
    if not payload.lstrip().startswith(b"<"):
        raise ValueError(f"Not an XML SVG: {source_path}")
    root = ElementTree.fromstring(payload)
    if not root.tag.lower().endswith("svg"):
        raise ValueError(f"Unexpected SVG root in {source_path}: {root.tag}")


def zip_candidates(archive: Path, provider: str, collection: str) -> Iterable[Candidate]:
    with zipfile.ZipFile(archive) as bundle:
        for info in bundle.infolist():
            path = PurePosixPath(info.filename)
            if info.is_dir() or path.suffix.lower() != ".svg":
                continue
            if "__MACOSX" in path.parts or path.name.startswith("._"):
                continue
            payload = bundle.read(info)
            valid_svg(payload, info.filename)
            yield Candidate(provider, info.filename, payload, collection)


def directory_candidates(root: Path, provider: str, collection: str) -> Iterable[Candidate]:
    for path in sorted(root.rglob("*.svg")):
        payload = path.read_bytes()
        relative = path.relative_to(root).as_posix()
        valid_svg(payload, relative)
        yield Candidate(provider, relative, payload, collection)


def aws_semantic_dedupe(candidates: Iterable[Candidate]) -> list[Candidate]:
    """Keep one current-size SVG for each AWS semantic icon, not every pixel variant."""
    chosen: dict[str, tuple[int, Candidate]] = {}
    for candidate in candidates:
        path = PurePosixPath(candidate.source_path)
        stem = re.sub(r"_(?:16|32|48|64)(?:_Dark)?$", "", path.stem, flags=re.I)
        identity = "/".join((*path.parts[:-2], stem)) if path.parent.name in {"16", "32", "48", "64"} else "/".join((*path.parts[:-1], stem))
        size_match = re.search(r"_(16|32|48|64)(?:_Dark)?$", path.stem, flags=re.I)
        size = int(size_match.group(1)) if size_match else 100
        if path.stem.lower().endswith("_dark"):
            size -= 1
        if identity not in chosen or size > chosen[identity][0]:
            chosen[identity] = (size, candidate)
    return [item[1] for item in sorted(chosen.values(), key=lambda value: value[1].source_path)]


def collection_record(identifier: str, provider: str, source: str, download: str, digest: str, version: str, count: int) -> dict:
    return {
        "id": identifier,
        "provider": provider,
        "source": source,
        "download": download,
        "version": version,
        "retrieved": "2026-08-24",
        "archiveSha256": digest,
        "assetCount": count,
        "managedImport": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aws", type=Path, required=True)
    parser.add_argument("--azure", type=Path, required=True)
    parser.add_argument("--gcp-core", type=Path, required=True)
    parser.add_argument("--gcp-category", type=Path, required=True)
    parser.add_argument("--ibm-svg", type=Path, required=True)
    args = parser.parse_args()

    sources = {
        "aws": aws_semantic_dedupe(zip_candidates(args.aws, "aws", "official-full-aws-2026-q3")),
        "azure": list(zip_candidates(args.azure, "azure", "official-full-azure-v24")),
        "gcp": [
            *zip_candidates(args.gcp_core, "gcp", "official-full-gcp-2025-core-category"),
            *zip_candidates(args.gcp_category, "gcp", "official-full-gcp-2025-core-category"),
        ],
        "ibm": list(directory_candidates(args.ibm_svg, "ibm", "official-full-ibm-v2.0.0")),
    }

    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    manifest["schemaVersion"] = 2
    manifest["retrieved"] = "2026-08-24"
    manifest["collections"] = [
        item for item in manifest.get("collections", [])
        if not item.get("id", "").startswith(MANAGED_COLLECTION_PREFIX)
    ]
    manifest["assets"] = {
        key: value for key, value in manifest.get("assets", {}).items()
        if not value.get("collection", "").startswith(MANAGED_COLLECTION_PREFIX)
    }

    for provider, candidates in sources.items():
        target_root = ASSET_ROOT / "icons" / f"{provider}-official"
        if target_root.exists():
            shutil.rmtree(target_root)
        target_root.mkdir(parents=True)
        for candidate in candidates:
            name = display_name(candidate.source_path)
            identifier = slug(name) or "icon"
            suffix = sha256(candidate.source_path.encode("utf-8"))[:8]
            filename = f"{identifier}--{suffix}.svg"
            target = target_root / filename
            target.write_bytes(candidate.payload)
            key = f"{provider}.{identifier}.{suffix}"
            category = PurePosixPath(candidate.source_path).parent.name
            manifest["assets"][key] = {
                "path": target.relative_to(ASSET_ROOT).as_posix(),
                "sha256": sha256(candidate.payload),
                "provider": provider,
                "displayName": name,
                "aliases": aliases(candidate.source_path),
                "category": category,
                "sourcePath": candidate.source_path,
                "collection": candidate.collection,
            }

    manifest["collections"].extend([
        collection_record(
            "official-full-aws-2026-q3", "AWS", "https://aws.amazon.com/architecture/icons/",
            "https://d1.awsstatic.com/onedam/marketing-channels/website/public/shared/architecture-icon-release/Icon-package_07312026.5846e92413caa21490223536cc97f1269e44fa92.zip",
            sha256(args.aws.read_bytes()), "2026-Q3", len(sources["aws"]),
        ),
        collection_record(
            "official-full-azure-v24", "Microsoft Azure", "https://learn.microsoft.com/azure/architecture/icons/",
            "https://arch-center.azureedge.net/icons/Azure_Public_Service_Icons_V24.zip",
            sha256(args.azure.read_bytes()), "V24 / July 2026", len(sources["azure"]),
        ),
        collection_record(
            "official-full-gcp-2025-core-category", "Google Cloud", "https://cloud.google.com/icons",
            "https://services.google.com/fh/files/misc/core-products-icons.zip + category-icons.zip",
            sha256(args.gcp_core.read_bytes() + args.gcp_category.read_bytes()), "2025 current icon system", len(sources["gcp"]),
        ),
        collection_record(
            "official-full-ibm-v2.0.0", "IBM Cloud", "https://github.com/IBM-Cloud/architecture-icons",
            "https://github.com/IBM-Cloud/architecture-icons/tree/v2.0.0/svg",
            "1c0f4d8b20b9b28ebb0a010ab8e5235cad94f081", "v2.0.0", len(sources["ibm"]),
        ),
    ])
    manifest["countsByProvider"] = {
        provider: len(candidates) for provider, candidates in sources.items()
    }
    manifest["totalOfficialProviderAssets"] = sum(manifest["countsByProvider"].values())
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"counts": manifest["countsByProvider"], "total": manifest["totalOfficialProviderAssets"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
