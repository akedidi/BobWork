#!/usr/bin/env python3
"""Generate a professional, icon-backed D2 view from an architecture model."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import unicodedata
from collections import defaultdict
from pathlib import Path
from typing import Any


PLUGIN_ROOT = Path(__file__).resolve().parent.parent
ICON_MANIFEST = PLUGIN_ROOT / "assets" / "icon-manifest.json"

ICON_BY_ID = {
    "app-gateway": "azure.application-gateway",
    "apim": "azure.api-management",
    "apim-gw-aks": "azure.api-management",
    "entra-id": "azure.managed-identity",
    "azure-openai": "azure.openai",
    "ai-search": "azure.ai-search",
    "cosmos-db": "azure.cosmos-db",
    "redis": "azure.redis",
    "key-vault": "azure.key-vault",
    "event-hubs": "azure.event-hubs",
    "acr": "azure.container-registry",
    "azure-monitor": "azure.monitor",
}

ICON_BY_TYPE = {
    "actor": "generic.user",
    "application": "generic.application",
    "compute": "generic.compute",
    "sidecar": "generic.application",
    "source-control": "generic.git-repository",
    "gitops": "generic.git-repository",
    "observability": "generic.observability",
    "monitoring": "generic.observability",
    "private-endpoint": "generic.private-link",
    "api-gateway": "generic.api",
    "api": "generic.api",
    "ingress": "generic.load-balancer",
    "load-balancer": "generic.load-balancer",
    "ai-service": "generic.ai-service",
    "agent": "generic.agent",
    "orchestrator": "generic.agent",
    "search": "generic.search",
    "database": "generic.database",
    "cache": "generic.cache",
    "secrets": "generic.security",
    "security": "generic.security",
    "identity": "generic.identity",
    "messaging": "generic.messaging",
    "queue": "generic.messaging",
    "registry": "generic.registry",
    "storage": "generic.storage",
    "object-storage": "generic.storage",
    "network": "generic.network",
    "edge": "generic.edge",
    "firewall": "generic.firewall",
}

PROVIDER_ALIASES = {
    "aws": "aws",
    "amazon": "aws",
    "amazon web services": "aws",
    "azure": "azure",
    "microsoft azure": "azure",
    "gcp": "gcp",
    "google": "gcp",
    "google cloud": "gcp",
    "ibm": "ibm",
    "ibm cloud": "ibm",
    "generic": "generic",
    "provider neutral": "generic",
}

CANONICAL_SERVICE_ALIASES = {
    ("aws", "s3"): "amazon simple storage service",
    ("aws", "amazon s3"): "amazon simple storage service",
    ("aws", "ec2"): "amazon elastic compute cloud",
    ("aws", "amazon ec2"): "amazon elastic compute cloud",
    ("aws", "rds"): "amazon relational database service",
    ("aws", "amazon rds"): "amazon relational database service",
    ("aws", "eks"): "amazon elastic kubernetes service",
    ("aws", "amazon eks"): "amazon elastic kubernetes service",
    ("aws", "ecs"): "amazon elastic container service",
    ("aws", "amazon ecs"): "amazon elastic container service",
    ("aws", "sqs"): "amazon simple queue service",
    ("aws", "amazon sqs"): "amazon simple queue service",
    ("aws", "sns"): "amazon simple notification service",
    ("aws", "amazon sns"): "amazon simple notification service",
}

OVERVIEW_EXCLUDED_TYPES = {
    "private-endpoint",
    "source-control",
    "gitops",
    "observability",
    "monitoring",
}

OPERATIONS_TYPES = {
    "source-control",
    "gitops",
    "observability",
    "monitoring",
    "identity",
    "registry",
    "compute",
    "sidecar",
}

TYPE_PRIORITY = {
    "actor": 100,
    "ingress": 95,
    "api-gateway": 92,
    "sidecar": 90,
    "compute": 88,
    "ai-service": 85,
    "search": 82,
    "database": 78,
    "cache": 76,
    "secrets": 74,
    "messaging": 72,
    "identity": 70,
    "registry": 68,
    "monitoring": 55,
    "observability": 52,
    "gitops": 50,
    "source-control": 48,
    "private-endpoint": 30,
}


def load(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        payload = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise RuntimeError("YAML input requires PyYAML; use JSON or install PyYAML") from exc
        payload = yaml.safe_load(text)
    return payload["architecture"]


def safe_id(value: str) -> str:
    result = re.sub(r"[^a-zA-Z0-9_]", "_", value)
    return f"n_{result}" if result[:1].isdigit() else result


def d2_string(value: Any) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def icon_catalog() -> dict[str, dict[str, str]]:
    if not ICON_MANIFEST.is_file():
        raise RuntimeError(f"Bundled icon manifest is missing: {ICON_MANIFEST}")
    return json.loads(ICON_MANIFEST.read_text(encoding="utf-8"))["assets"]


def normalized_words(value: Any) -> list[str]:
    normalized = unicodedata.normalize("NFKD", str(value or ""))
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii").lower()
    return re.findall(r"[a-z0-9]+", ascii_value)


def normalized_provider(value: Any) -> str:
    return PROVIDER_ALIASES.get(" ".join(normalized_words(value)), "")


def provider_icon_score(component: dict[str, Any], asset: dict[str, Any]) -> int:
    targets = [component.get("service"), component.get("label"), component.get("id")]
    candidates = [asset.get("displayName"), *(asset.get("aliases") or [])]
    best = 0
    ignored = {"aws", "amazon", "azure", "microsoft", "google", "cloud", "ibm", "service", "services"}
    for target in targets:
        raw_target_words = normalized_words(target)
        raw_target_text = " ".join(raw_target_words)
        target_words = [word for word in normalized_words(target) if word not in ignored]
        if not target_words:
            continue
        target_text = " ".join(target_words)
        target_set = set(target_words)
        for candidate in candidates:
            raw_candidate_words = normalized_words(candidate)
            raw_candidate_text = " ".join(raw_candidate_words)
            candidate_words = [word for word in normalized_words(candidate) if word not in ignored]
            if not candidate_words:
                continue
            candidate_text = " ".join(candidate_words)
            candidate_set = set(candidate_words)
            if raw_target_text == raw_candidate_text or raw_target_text.replace(" ", "") == raw_candidate_text.replace(" ", ""):
                score = 110
            elif target_text == candidate_text:
                score = 100
            elif target_text in candidate_text or candidate_text in target_text:
                score = 88 + min(8, len(target_set & candidate_set) * 2)
            else:
                overlap = len(target_set & candidate_set)
                union = len(target_set | candidate_set)
                score = int(80 * overlap / union) if union else 0
            best = max(best, score)
    return best


def canonical_service_component(component: dict[str, Any], provider: str) -> dict[str, Any]:
    normalized_service = " ".join(normalized_words(component.get("service") or component.get("label")))
    canonical = CANONICAL_SERVICE_ALIASES.get((provider, normalized_service))
    return {**component, "service": canonical} if canonical else component


def resolve_icon_key(
    component: dict[str, Any],
    catalog: dict[str, dict[str, Any]] | None = None,
) -> str | None:
    catalog = catalog or icon_catalog()
    icon = component.get("icon")
    if isinstance(icon, str) and icon in catalog:
        return icon
    component_id = component.get("id", "")
    if component_id in ICON_BY_ID and ICON_BY_ID[component_id] in catalog:
        return ICON_BY_ID[component_id]
    provider = normalized_provider(component.get("provider"))
    if provider in {"aws", "azure", "gcp", "ibm"}:
        component = canonical_service_component(component, provider)
        ranked = sorted(
            (
                (provider_icon_score(component, asset), key)
                for key, asset in catalog.items()
                if asset.get("provider") == provider
            ),
            key=lambda item: (-item[0], item[1]),
        )
        if ranked and ranked[0][0] >= 72:
            if len(ranked) > 1 and ranked[0][0] == ranked[1][0]:
                first_name = catalog[ranked[0][1]].get("displayName")
                second_name = catalog[ranked[1][1]].get("displayName")
                if first_name != second_name:
                    return None
            return ranked[0][1]
        return None
    return ICON_BY_TYPE.get(component.get("type", ""))


def materialize_icon(
    component: dict[str, Any],
    output_dir: Path,
    catalog: dict[str, dict[str, str]],
) -> str | None:
    key = resolve_icon_key(component, catalog)
    if not key:
        component_id = component.get("id", "<unknown>")
        component_type = component.get("type", "<missing>")
        raise RuntimeError(
            f"No professional icon mapping for component {component_id!r} "
            f"of type {component_type!r}; set a valid managed icon key explicitly"
        )
    asset = catalog.get(key)
    if not asset:
        raise RuntimeError(
            f"Managed icon {key!r} for component {component.get('id')!r} "
            "is absent from the bundled catalog"
        )
    relative = Path(asset["path"])
    source = PLUGIN_ROOT / "assets" / relative
    if not source.is_file():
        raise RuntimeError(f"Bundled icon is missing: {source}")
    target = output_dir / "assets" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return f"./assets/{relative.as_posix()}"


def select_components(
    architecture: dict[str, Any],
    view: str,
    max_components: int,
) -> list[dict[str, Any]]:
    components = list(architecture.get("components", []))
    if view == "all":
        selected = components
    elif view == "overview":
        selected = [
            component
            for component in components
            if component.get("type") not in OVERVIEW_EXCLUDED_TYPES
        ]
    elif view == "operations":
        selected = [
            component
            for component in components
            if component.get("type") in OPERATIONS_TYPES
        ]
    elif view == "deployment":
        selected = [
            component
            for component in components
            if component.get("type")
            not in {"source-control", "gitops", "observability", "monitoring"}
        ]
    else:
        raise ValueError(f"Unknown view: {view}")
    if len(selected) > max_components and view != "all":
        selected = sorted(
            selected,
            key=lambda item: (
                -TYPE_PRIORITY.get(item.get("type", ""), 0),
                item.get("id", ""),
            ),
        )[:max_components]
    return selected


def collapsed_relationships(
    architecture: dict[str, Any],
    selected_ids: set[str],
) -> list[dict[str, Any]]:
    relationships = list(architecture.get("relationships", []))
    by_source: dict[str, list[dict[str, Any]]] = defaultdict(list)
    component_types = {
        component["id"]: component.get("type")
        for component in architecture.get("components", [])
    }
    for relationship in relationships:
        by_source[relationship["from"]].append(relationship)

    result: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for relationship in relationships:
        source = relationship["from"]
        target = relationship["to"]
        candidates: list[dict[str, Any]] = []
        if source in selected_ids and target in selected_ids:
            candidates.append(dict(relationship))
        elif (
            source in selected_ids
            and component_types.get(target) == "private-endpoint"
            and target not in selected_ids
        ):
            for next_relationship in by_source.get(target, []):
                final_target = next_relationship["to"]
                if final_target not in selected_ids:
                    continue
                collapsed = dict(relationship)
                collapsed["id"] = f"{relationship.get('id', source)}-collapsed"
                collapsed["to"] = final_target
                collapsed["label"] = (
                    f"{relationship.get('label', 'Service call')} · Private Link"
                )
                candidates.append(collapsed)
        for candidate in candidates:
            key = (
                candidate["from"],
                candidate["to"],
                candidate.get("label", ""),
            )
            if key not in seen:
                seen.add(key)
                result.append(candidate)
    return result


def overview_group(component: dict[str, Any]) -> tuple[str, str]:
    kind = component.get("type")
    if kind == "actor":
        return "external", "Consumers"
    if kind in {"ingress", "api-gateway"}:
        return "edge", "Secure ingress"
    if kind in {"compute", "sidecar"}:
        return "workloads", "AKS workloads"
    if kind in {"ai-service", "search"}:
        return "ai", "AI services"
    if kind in {"database", "cache", "messaging", "registry"}:
        return "data", "Data & platform"
    if kind in {"identity", "secrets"}:
        return "security", "Identity & security"
    return "platform", "Platform services"


def operations_group(component: dict[str, Any]) -> tuple[str, str]:
    kind = component.get("type")
    if kind in {"source-control", "gitops", "registry"}:
        return "delivery", "Software delivery"
    if kind in {"monitoring", "observability"}:
        return "observe", "Observability"
    if kind == "identity":
        return "identity", "Identity"
    return "runtime", "Runtime"


def boundary_style(boundary_type: str) -> tuple[str, str]:
    if boundary_type in {"account", "subscription"}:
        return "#0078D4", "#F0F8FF"
    if boundary_type in {"network", "subnet"}:
        return "#0E7490", "#ECFEFF"
    if boundary_type == "kubernetes-namespace":
        return "#326CE5", "#EEF2FF"
    if boundary_type == "external":
        return "#64748B", "#F8FAFC"
    return "#94A3B8", "#F8FAFC"


def edge_class(relationship: dict[str, Any]) -> str:
    text = " ".join(
        str(relationship.get(key, ""))
        for key in ("label", "protocol", "classification")
    ).lower()
    if any(token in text for token in ("event", "async", "amqp", "audit")):
        return "flow_async"
    if any(token in text for token in ("git", "metric", "trace", "monitor", "identity", "oidc")):
        return "flow_mgmt"
    if "private" in text:
        return "flow_private"
    return "flow_primary"


def edge_label(relationship: dict[str, Any]) -> str:
    label = str(relationship.get("label", "")).strip()
    protocol = str(relationship.get("protocol", "")).strip()
    port = str(relationship.get("port", "")).strip()
    detail = " · ".join(part for part in (protocol, port) if part)
    return f"{label}\n{detail}" if label and detail else label or detail


def render_node(
    lines: list[str],
    indent: str,
    component: dict[str, Any],
    icon_path: str | None,
) -> None:
    node_id = safe_id(component["id"])
    label = component.get("label", component["id"])
    lines.append(f"{indent}{node_id}: {d2_string(label)} {{")
    lines.append(f"{indent}  class: service")
    if icon_path:
        lines.append(f"{indent}  icon: {d2_string(icon_path)}")
    lines.append(f"{indent}}}")


def render_logical_view(
    components: list[dict[str, Any]],
    view: str,
    output_dir: Path,
    catalog: dict[str, dict[str, str]],
) -> tuple[list[str], dict[str, str]]:
    group_fn = operations_group if view == "operations" else overview_group
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for component in components:
        groups[group_fn(component)].append(component)
    paths: dict[str, str] = {}
    lines: list[str] = []
    for (group_id, label), members in groups.items():
        lines.append(f"{safe_id(group_id)}: {d2_string(label)} {{")
        lines.append("  class: logical_boundary")
        for component in members:
            icon_path = materialize_icon(component, output_dir, catalog)
            render_node(lines, "  ", component, icon_path)
            paths[component["id"]] = f"{safe_id(group_id)}.{safe_id(component['id'])}"
        lines.append("}")
        lines.append("")
    return lines, paths


def render_deployment_view(
    architecture: dict[str, Any],
    components: list[dict[str, Any]],
    output_dir: Path,
    catalog: dict[str, dict[str, str]],
) -> tuple[list[str], dict[str, str]]:
    boundaries = {item["id"]: item for item in architecture.get("boundaries", [])}
    selected_boundary_ids = {item.get("boundary") for item in components if item.get("boundary")}
    for boundary_id in list(selected_boundary_ids):
        cursor = boundary_id
        while cursor and cursor in boundaries:
            selected_boundary_ids.add(cursor)
            cursor = boundaries[cursor].get("parent")

    child_boundaries: dict[str | None, list[dict[str, Any]]] = defaultdict(list)
    for boundary_id in selected_boundary_ids:
        boundary = boundaries[boundary_id]
        parent = boundary.get("parent")
        if parent not in selected_boundary_ids:
            parent = None
        child_boundaries[parent].append(boundary)
    components_by_boundary: dict[str | None, list[dict[str, Any]]] = defaultdict(list)
    for component in components:
        components_by_boundary[component.get("boundary")].append(component)

    paths: dict[str, str] = {}
    lines: list[str] = []

    def emit_boundary(boundary: dict[str, Any], indent: str, prefix: str) -> None:
        boundary_id = safe_id(boundary["id"])
        path = f"{prefix}.{boundary_id}" if prefix else boundary_id
        stroke, fill = boundary_style(boundary.get("type", ""))
        lines.append(f"{indent}{boundary_id}: {d2_string(boundary.get('label', boundary['id']))} {{")
        lines.append(f"{indent}  style.stroke: {d2_string(stroke)}")
        lines.append(f"{indent}  style.fill: {d2_string(fill)}")
        lines.append(f"{indent}  style.stroke-width: 2")
        for component in components_by_boundary.get(boundary["id"], []):
            icon_path = materialize_icon(component, output_dir, catalog)
            render_node(lines, indent + "  ", component, icon_path)
            paths[component["id"]] = f"{path}.{safe_id(component['id'])}"
        for child in sorted(child_boundaries.get(boundary["id"], []), key=lambda x: x["id"]):
            emit_boundary(child, indent + "  ", path)
        lines.append(f"{indent}}}")

    for boundary in sorted(child_boundaries.get(None, []), key=lambda x: x["id"]):
        emit_boundary(boundary, "", "")
        lines.append("")
    for component in components_by_boundary.get(None, []):
        icon_path = materialize_icon(component, output_dir, catalog)
        render_node(lines, "", component, icon_path)
        paths[component["id"]] = safe_id(component["id"])
    return lines, paths


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--view",
        choices=("auto", "overview", "deployment", "operations", "all"),
        default="auto",
    )
    parser.add_argument("--view-model", type=Path)
    parser.add_argument("--max-components", type=int, default=16)
    parser.add_argument("--direction", choices=("right", "down"))
    args = parser.parse_args()

    architecture = load(args.model)
    view = args.view
    if view == "auto":
        view = "overview" if len(architecture.get("components", [])) > 18 else "all"
    components = select_components(architecture, view, args.max_components)
    selected_ids = {component["id"] for component in components}
    relationships = collapsed_relationships(architecture, selected_ids)
    catalog = icon_catalog()
    output_dir = args.output.parent
    direction = args.direction or ("right" if view in {"overview", "operations"} else "down")

    lines = [
        "# Generated by Bob Work Cloud Architect",
        f"# View: {view} | Target: screen-sized landscape | Reading direction: {direction}",
        "vars: {",
        "  d2-config: {",
        "    layout-engine: elk",
        "    theme-id: 0",
        "  }",
        "}",
        f"direction: {direction}",
        "",
        "classes: {",
        "  service: {",
        "    width: 190",
        "    height: 92",
        "    style.fill: \"#FFFFFF\"",
        "    style.stroke: \"#64748B\"",
        "    style.stroke-width: 2",
        "    style.border-radius: 10",
        "    style.shadow: true",
        "    style.font-size: 14",
        "  }",
        "  logical_boundary: {",
        "    style.fill: \"#F8FAFC\"",
        "    style.stroke: \"#CBD5E1\"",
        "    style.stroke-width: 2",
        "    style.border-radius: 12",
        "    style.font-size: 15",
        "    style.bold: true",
        "  }",
        "  flow_primary: { style.stroke: \"#2563EB\"; style.stroke-width: 2; style.font-size: 12 }",
        "  flow_async: { style.stroke: \"#7C3AED\"; style.stroke-width: 2; style.stroke-dash: 5; style.font-size: 12 }",
        "  flow_mgmt: { style.stroke: \"#475569\"; style.stroke-width: 2; style.stroke-dash: 4; style.font-size: 12 }",
        "  flow_private: { style.stroke: \"#6D28D9\"; style.stroke-width: 2; style.font-size: 12 }",
        "}",
        "",
    ]

    if view in {"overview", "operations"}:
        node_lines, component_paths = render_logical_view(
            components, view, output_dir, catalog
        )
    else:
        node_lines, component_paths = render_deployment_view(
            architecture, components, output_dir, catalog
        )
    lines.extend(node_lines)

    view_relationships: list[dict[str, Any]] = []
    for relationship in relationships:
        source = component_paths.get(relationship["from"])
        target = component_paths.get(relationship["to"])
        if not source or not target:
            continue
        lines.append(
            f"{source} -> {target}: {d2_string(edge_label(relationship))} "
            f"{{ class: {edge_class(relationship)} }}"
        )
        view_relationships.append(relationship)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")

    view_components = []
    for component in components:
        enriched = dict(component)
        enriched["render_path"] = component_paths[component["id"]]
        icon_key = resolve_icon_key(component, catalog)
        if icon_key:
            enriched["icon"] = icon_key
        view_components.append(enriched)
    used_boundary_ids = {
        component.get("boundary") for component in components if component.get("boundary")
    }
    view_architecture = {
        **architecture,
        "name": f"{architecture.get('name', 'Architecture')} — {view.title()} view",
        "components": view_components,
        "relationships": view_relationships,
        "boundaries": [
            boundary
            for boundary in architecture.get("boundaries", [])
            if boundary["id"] in used_boundary_ids or view in {"deployment", "all"}
        ],
        "diagramView": {
            "id": view,
            "targetCanvas": "screen-sized landscape",
            "readingDirection": direction,
            "maxComponents": args.max_components,
            "officialIconsRequired": True,
        },
    }
    view_model = args.view_model or args.output.with_suffix(".model.json")
    view_model.write_text(
        json.dumps({"architecture": view_architecture}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "d2": str(args.output.resolve()),
                "model": str(view_model.resolve()),
                "view": view,
                "components": len(view_components),
                "relationships": len(view_relationships),
                "icons": sum(bool(component.get("icon")) for component in view_components),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
