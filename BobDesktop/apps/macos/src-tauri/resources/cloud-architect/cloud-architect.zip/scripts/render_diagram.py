#!/usr/bin/env python3
"""Route a normalized diagram model to D2, Mermaid, or PlantUML and deliver SVG+PNG."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parent
MERMAID = {"flowchart", "workflow", "sequence", "state", "journey"}
PLANTUML = {"uml-class", "uml-component", "uml-deployment", "uml-activity", "uml-use-case", "uml-sequence", "uml-state", "c4-context", "c4-container", "c4-component", "c4-dynamic", "c4-deployment"}


def run(*args: object) -> None:
    subprocess.run([str(arg) for arg in args], check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--name")
    args = parser.parse_args()
    payload = json.loads(args.model.read_text(encoding="utf-8"))
    diagram = payload.get("diagram", {})
    kind = diagram.get("type", "cloud-topology" if "architecture" in payload else None)
    if not kind:
        raise ValueError("Model must declare diagram.type")
    name = args.name or diagram.get("id") or kind
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    svg, png = output_dir / f"{name}.svg", output_dir / f"{name}.png"
    if kind == "cloud-topology":
        source, view_model = output_dir / f"{name}.d2", output_dir / f"{name}.view.json"
        run(sys.executable, SCRIPTS / "generate_professional_d2.py", args.model, "--output", source, "--view-model", view_model, "--direction", "right")
        run(sys.executable, SCRIPTS / "d2_runtime.py", source, svg, "--model", view_model)
        converter = shutil.which("rsvg-convert")
        if not converter:
            raise RuntimeError("rsvg-convert is required for deterministic D2 PNG export")
        run(converter, "-b", "#ffffff", "-w", "1920", "-o", png, svg)
        qa_model = view_model
    elif kind in MERMAID:
        source = output_dir / f"{name}.mmd"
        run(sys.executable, SCRIPTS / "generate_diagram_source.py", args.model, "--output", source)
        run(sys.executable, SCRIPTS / "mermaid_runtime.py", source, svg)
        run(sys.executable, SCRIPTS / "mermaid_runtime.py", source, png)
        qa_model = args.model
    elif kind in PLANTUML:
        source = output_dir / f"{name}.puml"
        run(sys.executable, SCRIPTS / "generate_diagram_source.py", args.model, "--output", source)
        run(sys.executable, SCRIPTS / "plantuml_runtime.py", source, svg)
        run(sys.executable, SCRIPTS / "plantuml_runtime.py", source, png)
        qa_model = args.model
    else:
        raise ValueError(f"Unsupported diagram type: {kind}")
    run(sys.executable, SCRIPTS / "qa_diagram.py", svg, "--model", qa_model)
    icons = [item.get("icon") for item in diagram.get("elements", []) if item.get("icon")]
    record = {"type": kind, "source": str(source.resolve()), "svg": str(svg), "png": str(png), "qa": "PASS"}
    if icons:
        record["icons"] = icons
    (output_dir / f"{name}.delivery.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
