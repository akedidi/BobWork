#!/usr/bin/env python3
"""Verify and run the bundled PlantUML renderer without network access."""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import subprocess
from pathlib import Path


ROOT = Path(os.environ["BOB_DIAGRAM_RUNTIME_ROOT"])
JAR = ROOT / "vendor" / "plantuml" / "plantuml-1.2026.4.jar"
CHECKSUMS = ROOT / "vendor" / "plantuml" / "SHA256SUMS"


def verify() -> str:
    if not JAR.is_file() or not CHECKSUMS.is_file():
        raise RuntimeError("Bundled PlantUML runtime is incomplete")
    expected = CHECKSUMS.read_text(encoding="utf-8").split()[0]
    actual = hashlib.sha256(JAR.read_bytes()).hexdigest()
    if actual != expected:
        raise RuntimeError("Bundled PlantUML checksum mismatch")
    result = subprocess.run(
        ["java", "-Djava.awt.headless=true", "-jar", str(JAR), "-version"],
        capture_output=True, text=True, timeout=15, check=True,
    )
    version = re.search(r"PlantUML version ([^ ]+)", result.stdout)
    return f"PlantUML {version.group(1) if version else 'unknown'}; sha256={actual}"


def render(source: Path, output: Path) -> None:
    verify()
    kind = output.suffix.lower().lstrip(".")
    if kind not in {"svg", "png"}:
        raise ValueError("PlantUML output must end in .svg or .png")
    result = subprocess.run(
        ["java", "-Djava.awt.headless=true", "-jar", str(JAR), f"-t{kind}", "-pipe", "-failfast2"],
        input=source.read_bytes(), capture_output=True, timeout=60,
    )
    if result.returncode != 0 or not result.stdout:
        raise RuntimeError(result.stderr.decode("utf-8", errors="replace") or "PlantUML render failed")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(result.stdout)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=Path)
    parser.add_argument("output", nargs="?", type=Path)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    if args.verify:
        print(verify())
        return 0
    if not args.input or not args.output:
        parser.error("input and output are required unless --verify is used")
    render(args.input, args.output)
    print(args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
