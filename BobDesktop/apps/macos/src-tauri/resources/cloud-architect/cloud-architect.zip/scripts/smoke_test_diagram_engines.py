#!/usr/bin/env python3
"""Render and QA one representative diagram for every supported engine/type."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
EXAMPLES = ROOT / "assets" / "examples"
DEFAULT_OUTPUT = ROOT / "test-artifacts" / "diagram-engine-matrix"


def item(item_id: str, label: str, **extra: object) -> dict:
    return {"id": item_id, "label": label, **extra}


def relation(source: str, target: str, label: str = "Uses", **extra: object) -> dict:
    return {"from": source, "to": target, "label": label, **extra}


def fixture(kind: str) -> dict:
    diagram: dict = {"id": f"smoke-{kind}", "title": f"Smoke test — {kind}", "type": kind, "direction": "TB"}
    if kind in {"flowchart", "workflow"}:
        diagram["elements"] = [item("request", "Request"), item("process", "Process"), item("result", "Result")]
        diagram["relationships"] = [relation("request", "process", "Submit"), relation("process", "result", "Deliver")]
    elif kind in {"sequence", "uml-sequence"}:
        diagram["participants"] = [item("client", "Client"), item("service", "Service")]
        diagram["messages"] = [relation("client", "service", "Request"), relation("service", "client", "Response", response=True)]
    elif kind in {"state", "uml-state"}:
        diagram["states"] = [item("idle", "Idle"), item("running", "Running")]
        diagram["transitions"] = [relation("*", "idle", "Start"), relation("idle", "running", "Execute"), relation("running", "*", "Finish")]
    elif kind == "journey":
        diagram["sections"] = [
            {"label": "Discover", "steps": [{"label": "Read guidance", "score": 4, "actors": ["Team"]}, {"label": "Select pattern", "score": 5, "actors": ["Architect"]}]},
            {"label": "Deliver", "steps": [{"label": "Provision platform", "score": 4, "actors": ["Platform"]}, {"label": "Pass gates", "score": 3, "actors": ["Security"]}]},
        ]
    elif kind == "uml-class":
        diagram["elements"] = [item("controller", "Controller", members=["+handle()"]), item("service", "Service", members=["+execute()"])]
        diagram["relationships"] = [relation("controller", "service", "delegates")]
    elif kind == "uml-component":
        diagram["elements"] = [item("gateway", "API Gateway", kind="component"), item("service", "Application Service", kind="component")]
        diagram["relationships"] = [relation("gateway", "service", "Routes")]
    elif kind == "uml-deployment":
        diagram["elements"] = [item("edge", "Edge Node", kind="node"), item("cluster", "Runtime Cluster", kind="node")]
        diagram["relationships"] = [relation("edge", "cluster", "HTTPS")]
    elif kind == "uml-activity":
        diagram["steps"] = [item("receive", "Receive request"), item("validate", "Validate request"), item("deliver", "Deliver result")]
    elif kind == "uml-use-case":
        diagram["elements"] = [item("operator", "Operator", kind="actor"), item("operate", "Operate platform", kind="usecase")]
        diagram["relationships"] = [relation("operator", "operate", "Performs")]
    elif kind == "c4-context":
        diagram["elements"] = [item("user", "Platform User", kind="person"), item("platform", "Cloud Platform", kind="system", description="Provides governed services")]
        diagram["relationships"] = [relation("user", "platform", "Uses", technology="HTTPS")]
    elif kind == "c4-container":
        diagram["elements"] = [item("user", "Platform User", kind="person"), item("api", "Platform API", kind="container", technology="Python", description="Serves requests")]
        diagram["relationships"] = [relation("user", "api", "Calls", technology="HTTPS")]
    elif kind == "c4-component":
        diagram["elements"] = [item("controller", "Request Controller", kind="component", technology="Python", description="Validates requests"), item("worker", "Task Worker", kind="component", technology="Python", description="Executes tasks")]
        diagram["styles"] = [{"tag": "async", "target": "relationship", "lineColor": "#7C3AED", "lineStyle": "dotted", "legend": "Asynchronous flow"}]
        diagram["relationships"] = [relation("controller", "worker", "Dispatches", technology="Events", tags=["async"])]
    elif kind == "c4-dynamic":
        diagram["elements"] = [item("user", "Platform User", kind="person"), item("api", "Platform API", kind="container", technology="Python", description="Serves requests"), item("worker", "Task Worker", kind="component", technology="Python", description="Executes tasks")]
        diagram["relationships"] = [relation("user", "api", "Calls", technology="HTTPS", order=1), relation("api", "worker", "Dispatches", technology="Events", order=2)]
    elif kind == "c4-deployment":
        diagram["boundaries"] = [item("cloud", "Cloud Provider", kind="cloud", technology="Provider"), item("region", "Primary Region", kind="region", technology="Region", parent="cloud")]
        diagram["elements"] = [item("runtime", "Application Runtime", kind="container", technology="Kubernetes", description="Runs workloads", parent="region")]
    else:
        raise ValueError(f"No smoke fixture for {kind}")
    return {"schemaVersion": 1, "diagram": diagram}


TYPES = [
    "flowchart", "workflow", "sequence", "state", "journey",
    "uml-class", "uml-component", "uml-deployment", "uml-activity", "uml-use-case", "uml-sequence", "uml-state",
    "c4-context", "c4-container", "c4-component", "c4-dynamic", "c4-deployment",
]


def run(command: list[object]) -> subprocess.CompletedProcess[str]:
    return subprocess.run([str(value) for value in command], text=True, capture_output=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--only", choices=["d2", *TYPES], action="append")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    selected = args.only or ["d2", *TYPES]
    results: list[dict] = []

    for kind in selected:
        case_dir = output / kind
        case_dir.mkdir(parents=True, exist_ok=True)
        if kind == "d2":
            model = EXAMPLES / "multicloud-reference.json"
        else:
            model = case_dir / "model.json"
            model.write_text(json.dumps(fixture(kind), indent=2) + "\n", encoding="utf-8")
            validation = run([sys.executable, SCRIPTS / "validate_diagram_model.py", model])
            if validation.returncode:
                results.append({"type": kind, "status": "FAIL", "stage": "model-validation", "error": validation.stderr.strip()})
                continue
        completed = run([sys.executable, SCRIPTS / "render_diagram.py", model, "--output-dir", case_dir])
        delivery = next(case_dir.glob("*.delivery.json"), None)
        record = {
            "type": kind,
            "status": "PASS" if completed.returncode == 0 else "FAIL",
            "stage": "render-and-qa",
            "delivery": str(delivery) if delivery else None,
        }
        if completed.returncode:
            record["error"] = (completed.stderr or completed.stdout).strip()[-4000:]
        results.append(record)
        print(f"{record['status']}: {kind}", flush=True)

    versions = {}
    for name in ("d2", "mermaid", "plantuml"):
        completed = run([sys.executable, SCRIPTS / f"{name}_runtime.py", "--verify"])
        versions[name] = (completed.stdout or completed.stderr).strip()
    report = {
        "status": "PASS" if all(item["status"] == "PASS" for item in results) else "FAIL",
        "passed": sum(item["status"] == "PASS" for item in results),
        "total": len(results),
        "versions": versions,
        "results": results,
    }
    report_path = output / "matrix-report.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    markdown = ["# Diagram engine smoke-test matrix", "", f"Overall: **{report['status']}** ({report['passed']}/{report['total']})", "", "| Type | Status | Stage |", "|---|---:|---|"]
    markdown.extend(f"| {item['type']} | {item['status']} | {item['stage']} |" for item in results)
    (output / "matrix-report.md").write_text("\n".join(markdown) + "\n", encoding="utf-8")
    print(report_path)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
