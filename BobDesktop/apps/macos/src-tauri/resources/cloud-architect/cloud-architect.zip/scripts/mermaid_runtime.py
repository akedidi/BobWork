#!/usr/bin/env python3
"""Render Mermaid diagrams offline with the bundled Mermaid browser bundle."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(os.environ["BOB_DIAGRAM_RUNTIME_ROOT"])
MERMAID_JS = ROOT / "vendor" / "mermaid" / "dist" / "mermaid.min.js"
PACKAGE = ROOT / "vendor" / "mermaid" / "package.json"
CHECKSUMS = ROOT / "vendor" / "mermaid" / "SHA256SUMS"
CHROME_CANDIDATES = (
    Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    Path("/Applications/Chromium.app/Contents/MacOS/Chromium"),
)


def chrome_path() -> Path:
    for candidate in CHROME_CANDIDATES:
        if candidate.exists():
            return candidate
    for name in ("google-chrome", "chromium", "chromium-browser"):
        resolved = shutil.which(name)
        if resolved:
            return Path(resolved)
    raise RuntimeError("Google Chrome or Chromium is required for offline Mermaid rendering")


def verify() -> str:
    if not MERMAID_JS.is_file() or not PACKAGE.is_file() or not CHECKSUMS.is_file():
        raise RuntimeError("Bundled Mermaid runtime is incomplete")
    expected = CHECKSUMS.read_text(encoding="utf-8").split()[0]
    actual = hashlib.sha256(MERMAID_JS.read_bytes()).hexdigest()
    if actual != expected:
        raise RuntimeError("Bundled Mermaid checksum mismatch")
    version = json.loads(PACKAGE.read_text(encoding="utf-8"))["version"]
    browser = chrome_path()
    return f"Mermaid {version}; browser={browser}; sha256={actual}"


def replace_journey_faces(svg: str, definition: str) -> str:
    """Replace Mermaid's emotive journey faces with neutral numeric score badges."""
    if not re.search(r"^\s*journey\s*$", definition, flags=re.MULTILINE):
        return svg
    scores = re.findall(r"^\s+[^:\n]+:\s*([1-5])\s*:", definition, flags=re.MULTILINE)
    score_iter = iter(scores)
    face = re.compile(
        r'<circle cx="([0-9.]+)" cy="([0-9.]+)" class="face"[^>]*></circle><g>.*?</g>',
        flags=re.DOTALL,
    )

    def badge(match: re.Match[str]) -> str:
        score = next(score_iter, "-")
        x, y = match.group(1), match.group(2)
        return (
            f'<g class="journey-score"><circle cx="{x}" cy="{y}" r="15" fill="#E8F1FF" '
            f'stroke="#2563EB" stroke-width="2"></circle><text x="{x}" y="{float(y) + 5:g}" '
            f'text-anchor="middle" font-size="13" font-weight="700" fill="#174EA6">{score}</text></g>'
        )

    return face.sub(badge, svg)


def render(source: Path, output: Path, theme: str, background: str) -> None:
    verify()
    if output.suffix.lower() not in {".svg", ".png"}:
        raise ValueError("Mermaid output must end in .svg or .png")
    definition = source.read_text(encoding="utf-8")
    with tempfile.TemporaryDirectory(prefix="bob-mermaid-") as tmp:
        tmp_dir = Path(tmp)
        html = tmp_dir / "render.html"
        rendered_svg = tmp_dir / "rendered.svg"
        html.write_text(
            "<!doctype html><meta charset='utf-8'><style>body{margin:0;background:"
            + background
            + ";font-family:Inter,Arial,sans-serif}</style><div id='status'>WAIT</div>"
            + f"<script src={json.dumps(MERMAID_JS.as_uri())}></script><script>"
            + "(async()=>{try{mermaid.initialize({startOnLoad:false,securityLevel:'strict',"
            + f"theme:{json.dumps(theme)},fontFamily:'Inter,Arial,sans-serif',flowchart:{{htmlLabels:false}}}});"
            + f"const r=await mermaid.render('bobDiagram',{json.dumps(definition)});"
            + "document.body.innerHTML='<div id=\"status\">READY</div>'+r.svg;"
            + "}catch(e){document.body.innerHTML='<div id=\"status\">ERROR:'+String(e)+'</div>'}})();</script>",
            encoding="utf-8",
        )
        command = [
            str(chrome_path()), "--headless=new", "--disable-gpu", "--no-first-run",
            "--no-default-browser-check", "--allow-file-access-from-files",
            "--virtual-time-budget=12000", "--dump-dom", html.as_uri(),
        ]
        process = subprocess.run(command, capture_output=True, text=True, timeout=30)
        if process.returncode != 0 or "<div id=\"status\">READY</div>" not in process.stdout:
            detail = process.stderr.strip() or process.stdout[:1000]
            raise RuntimeError(f"Mermaid render failed: {detail}")
        match = re.search(r"(<svg\b.*?</svg>)", process.stdout, flags=re.DOTALL)
        if not match:
            raise RuntimeError("Mermaid did not return an SVG")
        svg_text = re.sub(
            r"(<svg\b[^>]*>)",
            lambda found: found.group(1) + f'<rect width="100%" height="100%" fill="{background}"/>',
            match.group(1), count=1,
        )
        svg_text = replace_journey_faces(svg_text, definition)
        rendered_svg.write_text(svg_text, encoding="utf-8")
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.suffix.lower() == ".svg":
            shutil.copy2(rendered_svg, output)
        else:
            root = ET.fromstring(svg_text)
            viewbox = [float(value) for value in root.attrib.get("viewBox", "0 0 1200 800").split()]
            source_width, source_height = viewbox[2], viewbox[3]
            target_width = 1920
            target_height = max(240, round(target_width * source_height / source_width))
            preview = tmp_dir / "preview.html"
            preview.write_text(
                "<!doctype html><meta charset='utf-8'><style>html,body{margin:0;overflow:hidden;background:"
                + background
                + ";}svg{display:block;max-width:none!important;width:100vw!important;height:100vh!important}</style>"
                + svg_text,
                encoding="utf-8",
            )
            screenshot = subprocess.run(
                [
                    str(chrome_path()), "--headless=new", "--disable-gpu", "--no-first-run",
                    "--no-default-browser-check", "--allow-file-access-from-files", "--hide-scrollbars",
                    "--force-device-scale-factor=1", f"--window-size={target_width},{target_height}",
                    f"--screenshot={output.resolve()}", preview.as_uri(),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if screenshot.returncode != 0 or not output.is_file() or output.stat().st_size == 0:
                detail = screenshot.stderr.strip() or screenshot.stdout[:1000]
                raise RuntimeError(f"Mermaid PNG screenshot failed: {detail}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=Path)
    parser.add_argument("output", nargs="?", type=Path)
    parser.add_argument("--theme", default="neutral", choices=("default", "neutral", "dark", "forest", "base"))
    parser.add_argument("--background", default="#ffffff")
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    if args.verify:
        print(verify())
        return 0
    if not args.input or not args.output:
        parser.error("input and output are required unless --verify is used")
    render(args.input, args.output, args.theme, args.background)
    print(args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
