#!/usr/bin/env python3
"""Generate Mermaid or PlantUML source from the normalized Bob diagram model."""

from __future__ import annotations

import argparse
import copy
import json
import re
import shutil
import subprocess
from pathlib import Path


MERMAID_TYPES = {"flowchart", "workflow", "sequence", "state", "journey"}
PLANTUML_TYPES = {"uml-class", "uml-component", "uml-deployment", "uml-activity", "uml-use-case", "uml-sequence", "uml-state", "c4-context", "c4-container", "c4-component", "c4-dynamic", "c4-deployment"}
C4_TYPES = {"c4-context", "c4-container", "c4-component", "c4-dynamic", "c4-deployment"}
ROOT = Path(__file__).resolve().parent.parent
ICON_MANIFEST = ROOT / "assets" / "icon-manifest.json"
MERMAID_SVG_TEXT = '%%{init: {"htmlLabels": false, "flowchart": {"htmlLabels": false}}}%%'


def ident(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_]", "_", value)
    return value if not value[:1].isdigit() else f"n_{value}"


def text(value: object) -> str:
    return str(value or "").replace("\n", " ").replace('"', "'")


def model_root(payload: dict) -> dict:
    return payload.get("diagram", payload)


def tags(item: dict) -> str:
    value = item.get("tags", [])
    if isinstance(value, str):
        return value
    return "+".join(text(tag) for tag in value if text(tag))


def named(name: str, value: object) -> str:
    return f'${name}="{text(value)}"' if value not in (None, "", []) else ""


def c4_style_lines(model: dict) -> list[str]:
    lines: list[str] = []
    for style in model.get("styles", []):
        tag = text(style.get("tag"))
        if not tag:
            continue
        target = style.get("target", "element")
        args = [
            named("bgColor", style.get("background")),
            named("fontColor", style.get("fontColor")),
            named("borderColor", style.get("borderColor")),
            named("legendText", style.get("legend")),
        ]
        if target == "relationship":
            args = [
                named("textColor", style.get("fontColor")),
                named("lineColor", style.get("lineColor") or style.get("borderColor")),
                named("legendText", style.get("legend")),
            ]
            line_style = {"dashed": "DashedLine()", "dotted": "DottedLine()"}.get(style.get("lineStyle"))
            if line_style:
                args.append(f"$lineStyle={line_style}")
            macro = "AddRelTag"
        elif target == "boundary":
            macro = "AddBoundaryTag"
        else:
            macro = "AddElementTag"
        rendered = ", ".join(arg for arg in args if arg)
        lines.append(f'{macro}("{tag}"{", " + rendered if rendered else ""})')
    return lines


def c4_element_line(element: dict, level: str) -> str:
    alias = ident(element["id"])
    label = text(element.get("label", element["id"]))
    if element.get("_icon_path"):
        label = f'<img:{element["_icon_path"]}{{scale={element.get("_icon_scale", 1)}}}>\\n{label}'
    description = text(element.get("description", ""))
    technology = text(element.get("technology", ""))
    kind = str(element.get("kind", "")).lower()
    external = bool(element.get("external")) or kind.startswith("external-")
    kind = kind.removeprefix("external-")
    if kind in {"person", "actor", "user"}:
        macro = "Person_Ext" if external else "Person"
        return f'{macro}({alias}, "{label}", "{description}", $tags="{tags(element)}")'
    if kind == "system" or level == "context":
        macro = "System_Ext" if external else "System"
        return f'{macro}({alias}, "{label}", "{description}", $tags="{tags(element)}")'
    base = "Component" if level in {"component", "dynamic"} and kind not in {"container", "database", "queue"} else "Container"
    if kind == "component":
        base = "Component"
    if kind in {"database", "store"}:
        base += "Db"
    elif kind in {"queue", "topic", "event-stream"}:
        base += "Queue"
    macro = f"{base}_Ext" if external else base
    return f'{macro}({alias}, "{label}", "{technology}", "{description}", $tags="{tags(element)}")'


def c4_boundary_line(boundary: dict, level: str) -> str:
    alias = ident(boundary["id"])
    label = text(boundary.get("label", boundary["id"]))
    kind = str(boundary.get("kind", "boundary")).lower()
    description = text(boundary.get("description", ""))
    technology = text(boundary.get("technology", boundary.get("type", "")))
    tag_value = tags(boundary)
    if level == "deployment" and kind in {"deployment-node", "cloud", "region", "availability-zone", "network", "subnet", "kubernetes", "cluster", "namespace"}:
        return f'Deployment_Node({alias}, "{label}", "{technology or kind}", "{description}", $tags="{tag_value}")'
    macro = {
        "enterprise": "Enterprise_Boundary",
        "system": "System_Boundary",
        "container": "Container_Boundary",
    }.get(kind)
    if macro:
        return f'{macro}({alias}, "{label}", $tags="{tag_value}", $descr="{description}")'
    return f'Boundary({alias}, "{label}", "{technology or kind}", $tags="{tag_value}", $descr="{description}")'


def render_c4_structure(model: dict, level: str) -> list[str]:
    elements = model.get("elements", [])
    boundaries = model.get("boundaries", [])
    lines: list[str] = []

    def render(parent: str | None, indent: str = "") -> None:
        for boundary in (item for item in boundaries if item.get("parent") == parent):
            lines.append(f"{indent}{c4_boundary_line(boundary, level)} {{")
            render(boundary["id"], indent + "  ")
            lines.append(f"{indent}}}")
        for element in (item for item in elements if item.get("parent") == parent):
            lines.append(f"{indent}{c4_element_line(element, level)}")

    render(None)
    return lines


def prepare_c4_icons(payload: dict, output_dir: Path) -> dict:
    prepared = copy.deepcopy(payload)
    model = model_root(prepared)
    requested = [element for element in model.get("elements", []) if element.get("icon")]
    if not requested:
        return prepared
    manifest = json.loads(ICON_MANIFEST.read_text(encoding="utf-8"))
    assets = manifest.get("assets", {})
    icon_dir = output_dir.resolve() / "c4-icons"
    icon_dir.mkdir(parents=True, exist_ok=True)
    for element in requested:
        key = str(element["icon"])
        asset = assets.get(key)
        if not asset:
            raise ValueError(f"Unknown managed icon key: {key}")
        source = ROOT / "assets" / asset["path"]
        if not source.is_file():
            raise FileNotFoundError(f"Managed icon is missing: {source}")
        target = icon_dir / f"{ident(key)}.png"
        converter = shutil.which("rsvg-convert")
        if not converter:
            raise RuntimeError("rsvg-convert is required to embed official C4 icons")
        # PlantUML can embed SVG-in-SVG, but the deterministic PNG renderer does
        # not preserve every nested provider SVG. A 48px lossless PNG derivative
        # keeps the official artwork visible in both delivery formats.
        subprocess.run(
            [converter, "--keep-aspect-ratio", "-w", "48", "-h", "48", "-o", str(target), str(source)],
            check=True,
        )
        element["_icon_path"] = str(target)
        element["_icon_scale"] = "1"
    return prepared


def mermaid(model: dict) -> str:
    kind = model["type"]
    title = text(model.get("title", "Architecture diagram"))
    if kind in {"flowchart", "workflow"}:
        lines = [f"---\ntitle: {title}\n---", MERMAID_SVG_TEXT, f"flowchart {model.get('direction', 'LR')}"]
        for node in model.get("elements", model.get("nodes", [])):
            shape = node.get("shape", "rounded")
            left, right = ("([", "])" ) if shape == "rounded" else ("[", "]")
            lines.append(f"  {ident(node['id'])}{left}\"{text(node.get('label', node['id']))}\"{right}")
        for rel in model.get("relationships", model.get("edges", [])):
            label = f"|{text(rel.get('label'))}|" if rel.get("label") else ""
            lines.append(f"  {ident(rel['from'])} -->{label} {ident(rel['to'])}")
        return "\n".join(lines) + "\n"
    if kind == "sequence":
        lines = [f"---\ntitle: {title}\n---", MERMAID_SVG_TEXT, "sequenceDiagram", "  autonumber"]
        for actor in model.get("participants", []):
            lines.append(f"  participant {ident(actor['id'])} as {text(actor.get('label', actor['id']))}")
        for msg in model.get("messages", []):
            arrow = "-->>" if msg.get("response") else "->>"
            lines.append(f"  {ident(msg['from'])}{arrow}{ident(msg['to'])}: {text(msg.get('label'))}")
        return "\n".join(lines) + "\n"
    if kind == "state":
        lines = [f"---\ntitle: {title}\n---", MERMAID_SVG_TEXT, "stateDiagram-v2"]
        for state in model.get("states", []):
            lines.append(f"  state \"{text(state.get('label', state['id']))}\" as {ident(state['id'])}")
        for transition in model.get("transitions", []):
            source = "[*]" if transition["from"] == "*" else ident(transition["from"])
            target = "[*]" if transition["to"] == "*" else ident(transition["to"])
            suffix = f": {text(transition.get('label'))}" if transition.get("label") else ""
            lines.append(f"  {source} --> {target}{suffix}")
        return "\n".join(lines) + "\n"
    if kind == "journey":
        lines = [MERMAID_SVG_TEXT, "journey", f"  title {title}"]
        for section in model.get("sections", []):
            lines.append(f"  section {text(section['label'])}")
            for step in section.get("steps", []):
                actors = ", ".join(text(a) for a in step.get("actors", ["User"]))
                lines.append(f"    {text(step['label'])}: {int(step.get('score', 3))}: {actors}")
        return "\n".join(lines) + "\n"
    raise ValueError(f"Unsupported Mermaid type: {kind}")


def plantuml(model: dict) -> str:
    kind = model["type"]
    lines = ["@startuml", "skinparam backgroundColor #FFFFFF", "skinparam shadowing false", "skinparam roundcorner 12", f"title {text(model.get('title', 'Architecture diagram'))}"]
    if kind.startswith("c4-"):
        level = kind.split("-", 1)[1].lower()
        include_name = {"context": "Context", "container": "Container", "component": "Component", "dynamic": "Dynamic", "deployment": "Deployment"}[level]
        layout = "LAYOUT_LEFT_RIGHT()" if model.get("direction") in {"LR", "RL"} else "LAYOUT_TOP_DOWN()"
        lines[1:1] = ["!NEW_C4_STYLE=1", "!ROUNDED_STYLE=1", f"!include <C4/C4_{include_name}>", layout]
        lines.extend(c4_style_lines(model))
        lines.extend(render_c4_structure(model, level))
        for index, rel in enumerate(model.get("relationships", []), start=1):
            macro = {"R": "Rel_R", "L": "Rel_L", "U": "Rel_U", "D": "Rel_D", "back": "Rel_Back"}.get(rel.get("direction"), "Rel")
            args = [ident(rel["from"]), ident(rel["to"]), f'"{text(rel.get("label"))}"']
            args.append(named("techn", rel.get("technology")) or '$techn=""')
            if tags(rel):
                args.append(named("tags", tags(rel)))
            if level == "dynamic":
                args.append(named("index", rel.get("order", index)))
            lines.append(f'{macro}({", ".join(args)})')
        if model.get("legend", True):
            lines.append("SHOW_LEGEND()")
        if model.get("showVersion"):
            lines.append("C4VersionDetails()")
    elif kind == "uml-sequence":
        for actor in model.get("participants", []):
            lines.append(f'participant "{text(actor.get("label", actor["id"]))}" as {ident(actor["id"])}')
        for msg in model.get("messages", []):
            arrow = "-->" if msg.get("response") else "->"
            lines.append(f'{ident(msg["from"])} {arrow} {ident(msg["to"])} : {text(msg.get("label"))}')
    elif kind == "uml-state":
        for state in model.get("states", []):
            lines.append(f'state "{text(state.get("label", state["id"]))}" as {ident(state["id"])}')
        for transition in model.get("transitions", []):
            source = "[*]" if transition["from"] == "*" else ident(transition["from"])
            target = "[*]" if transition["to"] == "*" else ident(transition["to"])
            lines.append(f'{source} --> {target} : {text(transition.get("label"))}')
    elif kind == "uml-class":
        for item in model.get("elements", []):
            lines.append(f'class "{text(item.get("label", item["id"]))}" as {ident(item["id"])} {{')
            lines.extend(f'  {text(member)}' for member in item.get("members", []))
            lines.append("}")
        for rel in model.get("relationships", []):
            arrow = rel.get("arrow", "-->")
            lines.append(f'{ident(rel["from"])} {arrow} {ident(rel["to"])} : {text(rel.get("label"))}')
    elif kind in {"uml-component", "uml-deployment"}:
        keyword = "node" if kind == "uml-deployment" else "component"
        for item in model.get("elements", []):
            item_keyword = item.get("kind", keyword)
            lines.append(f'{item_keyword} "{text(item.get("label", item["id"]))}" as {ident(item["id"])}')
        for rel in model.get("relationships", []):
            lines.append(f'{ident(rel["from"])} --> {ident(rel["to"])} : {text(rel.get("label"))}')
    elif kind == "uml-activity":
        lines.append("start")
        for step in model.get("steps", []):
            if step.get("kind") == "decision":
                lines.append(f'if ({text(step["label"])}) then (yes)')
            elif step.get("kind") == "end-decision":
                lines.append("endif")
            else:
                lines.append(f':{text(step["label"])};')
        lines.append("stop")
    elif kind == "uml-use-case":
        for item in model.get("elements", []):
            keyword = "actor" if item.get("kind") == "actor" else "usecase"
            lines.append(f'{keyword} "{text(item.get("label", item["id"]))}" as {ident(item["id"])}')
        for rel in model.get("relationships", []):
            lines.append(f'{ident(rel["from"])} --> {ident(rel["to"])} : {text(rel.get("label"))}')
    else:
        raise ValueError(f"Unsupported PlantUML type: {kind}")
    lines.append("@enduml")
    return "\n".join(lines) + "\n"


def generate(payload: dict) -> tuple[str, str]:
    model = model_root(payload)
    kind = model.get("type")
    if kind in MERMAID_TYPES:
        return mermaid(model), ".mmd"
    if kind in PLANTUML_TYPES:
        return plantuml(model), ".puml"
    raise ValueError(f"Unsupported diagram type: {kind}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    payload = json.loads(args.model.read_text(encoding="utf-8"))
    if model_root(payload).get("type") in C4_TYPES:
        payload = prepare_c4_icons(payload, args.output.parent)
    source, suffix = generate(payload)
    if args.output.suffix.lower() != suffix:
        raise ValueError(f"{model_root(payload)['type']} requires a {suffix} output")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(source, encoding="utf-8")
    print(args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
