#!/usr/bin/env python3
"""Validate provider coverage, asset integrity, and semantic icon resolution."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from xml.etree import ElementTree


PLUGIN_ROOT = Path(__file__).resolve().parent.parent
MANIFEST = PLUGIN_ROOT / "assets" / "icon-manifest.json"
MINIMUM_COUNTS = {"aws": 900, "azure": 700, "gcp": 40, "ibm": 250}
RESOLUTION_CASES = [
    ({"id": "s3", "label": "Amazon S3", "service": "Amazon S3", "provider": "AWS", "type": "object-storage"}, "aws"),
    ({"id": "app-service", "label": "Azure App Service", "service": "App Services", "provider": "Azure", "type": "compute"}, "azure"),
    ({"id": "cloud-run", "label": "Cloud Run", "service": "Cloud Run", "provider": "Google Cloud", "type": "compute"}, "gcp"),
    ({"id": "ibm-vpc", "label": "IBM Cloud VPC", "service": "IBM Cloud VPC", "provider": "IBM Cloud", "type": "network"}, "ibm"),
]


def load_generator():
    path = PLUGIN_ROOT / "scripts" / "generate_professional_d2.py"
    spec = importlib.util.spec_from_file_location("cloud_architect_generator", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-hashes", action="store_true")
    args = parser.parse_args()
    payload = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assets = payload.get("assets", {})
    errors: list[str] = []

    counts = {provider: 0 for provider in MINIMUM_COUNTS}
    paths: set[str] = set()
    for key, asset in assets.items():
        provider = asset.get("provider")
        if provider in counts:
            counts[provider] += 1
        relative = asset.get("path", "")
        if relative in paths:
            errors.append(f"duplicate asset path: {relative}")
        paths.add(relative)
        path = PLUGIN_ROOT / "assets" / relative
        if not path.is_file():
            errors.append(f"missing asset for {key}: {path}")
            continue
        try:
            root = ElementTree.parse(path).getroot()
            if not root.tag.lower().endswith("svg"):
                errors.append(f"not an SVG root for {key}: {root.tag}")
        except ElementTree.ParseError as exc:
            errors.append(f"invalid SVG for {key}: {exc}")
        if args.verify_hashes:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != asset.get("sha256"):
                errors.append(f"checksum mismatch for {key}")

    for provider, minimum in MINIMUM_COUNTS.items():
        if counts[provider] < minimum:
            errors.append(f"{provider} coverage {counts[provider]} is below {minimum}")

    generator = load_generator()
    for component, expected_provider in RESOLUTION_CASES:
        key = generator.resolve_icon_key(component, assets)
        if not key or assets.get(key, {}).get("provider") != expected_provider:
            errors.append(f"semantic resolution failed for {component['label']}: {key}")

    for error in errors:
        print(f"ERROR: {error}")
    print(f"RESULT: {'PASS' if not errors else 'FAIL'} counts={counts} total={sum(counts.values())}")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
