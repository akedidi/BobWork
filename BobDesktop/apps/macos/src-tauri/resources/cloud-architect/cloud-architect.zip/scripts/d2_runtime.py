#!/usr/bin/env python3
"""Verify and run the D2 renderer bundled with the Bob Work plugin."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
from pathlib import Path


# Diagram engines are platform capabilities. The plugin owns architecture
# semantics only; Runtime Manager injects this shared runtime root for hooks.
RUNTIME_ROOT = Path(os.environ["BOB_DIAGRAM_RUNTIME_ROOT"]) / "vendor" / "d2" / "v0.7.1"
BINARY = RUNTIME_ROOT / "bin" / "d2"
METADATA = RUNTIME_ROOT / "runtime.json"
EXPECTED_VERSION = "0.7.1"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_runtime() -> dict[str, str]:
    if not METADATA.is_file():
        raise RuntimeError(f"D2 metadata is missing: {METADATA}")
    if not BINARY.is_file() or not os.access(BINARY, os.X_OK):
        raise RuntimeError(f"Bundled D2 executable is missing or not executable: {BINARY}")

    metadata = json.loads(METADATA.read_text(encoding="utf-8"))
    expected_hash = metadata.get("binary_sha256")
    actual_hash = sha256(BINARY)
    if not expected_hash or actual_hash != expected_hash:
        raise RuntimeError(
            f"Bundled D2 SHA-256 mismatch: expected {expected_hash}, got {actual_hash}"
        )

    completed = subprocess.run(
        [str(BINARY), "--version"],
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    actual_version = (completed.stdout or completed.stderr).strip()
    if actual_version != EXPECTED_VERSION:
        raise RuntimeError(
            f"Bundled D2 version mismatch: expected {EXPECTED_VERSION}, got {actual_version}"
        )

    expected_platform = metadata.get("platform")
    actual_platform = f"{platform.system().lower()}-{platform.machine().lower()}"
    if expected_platform and expected_platform != actual_platform:
        raise RuntimeError(
            f"Bundled D2 platform mismatch: expected {expected_platform}, got {actual_platform}"
        )

    return {
        "binary": str(BINARY),
        "binary_sha256": actual_hash,
        "platform": actual_platform,
        "version": actual_version,
    }


def safe_id(value: str) -> str:
    result = re.sub(r"[^a-zA-Z0-9_]", "_", value)
    return f"n_{result}" if result[:1].isdigit() else result


def annotate_svg(svg: Path, model: Path) -> int:
    payload = json.loads(model.read_text(encoding="utf-8"))["architecture"]
    component_paths = []
    for component in payload.get("components", []):
        render_path = component.get("render_path")
        if render_path:
            component_paths.append(render_path)
            continue
        node = safe_id(component["id"])
        boundary = component.get("boundary")
        component_paths.append(f"{safe_id(boundary)}.{node}" if boundary else node)

    source = svg.read_text(encoding="utf-8")
    annotated = 0
    for component_path in component_paths:
        class_name = base64.b64encode(component_path.encode("utf-8")).decode("ascii")
        pattern = re.compile(rf'class="({re.escape(class_name)}(?: [^"]*)?)"')
        source, replacements = pattern.subn(r'class="\1 node"', source, count=1)
        annotated += replacements
    if annotated != len(component_paths):
        raise RuntimeError(
            f"D2 SVG annotation mismatch: annotated {annotated} of {len(component_paths)} model components"
        )
    svg.write_text(source, encoding="utf-8")
    return annotated


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=Path, help="Editable D2 source")
    parser.add_argument("output", nargs="?", type=Path, help="Rendered SVG or PNG")
    parser.add_argument("--model", type=Path, help="Architecture model used for SVG QA annotations")
    parser.add_argument("--layout", default="elk", help="D2 layout engine (default: elk)")
    parser.add_argument("--theme", type=int, default=0, help="D2 theme identifier")
    parser.add_argument("--timeout", type=int, default=120, help="Render timeout in seconds")
    parser.add_argument("--verify", action="store_true", help="Verify the pinned runtime")
    args = parser.parse_args()

    runtime = verify_runtime()
    if args.verify:
        print(json.dumps(runtime, ensure_ascii=False, sort_keys=True))
        return 0

    if args.input is None or args.output is None:
        parser.error("input and output are required unless --verify is used")
    if not args.input.is_file():
        raise FileNotFoundError(args.input)
    if args.output.suffix.lower() == ".svg" and (args.model is None or not args.model.is_file()):
        parser.error("--model is required for SVG rendering and QA traceability")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    command = [
        runtime["binary"],
        "--layout",
        args.layout,
        "--theme",
        str(args.theme),
        "--bundle",
        "--pad",
        "48",
        str(args.input),
        str(args.output),
    ]
    subprocess.run(command, check=True, timeout=args.timeout, cwd=args.input.parent)
    if not args.output.is_file() or args.output.stat().st_size == 0:
        raise RuntimeError(f"D2 did not create a valid output file: {args.output}")

    annotated_nodes = 0
    if args.output.suffix.lower() == ".svg":
        annotated_nodes = annotate_svg(args.output, args.model)

    result = dict(runtime)
    result["output"] = str(args.output.resolve())
    result["output_sha256"] = sha256(args.output)
    result["annotated_nodes"] = annotated_nodes
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
        print(f"D2 runtime error: {exc}", file=sys.stderr)
        raise SystemExit(1)
