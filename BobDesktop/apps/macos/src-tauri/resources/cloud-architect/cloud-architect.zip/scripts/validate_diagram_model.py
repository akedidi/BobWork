#!/usr/bin/env python3
"""Validate normalized diagram models and their internal references."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


SUPPORTED = {"flowchart", "workflow", "sequence", "state", "journey", "uml-class", "uml-component", "uml-deployment", "uml-activity", "uml-use-case", "uml-sequence", "uml-state", "c4-context", "c4-container", "c4-component", "c4-dynamic", "c4-deployment"}


def validate(payload: dict) -> list[str]:
    errors: list[str] = []
    if payload.get("schemaVersion") != 1:
        errors.append("schemaVersion must be 1")
    diagram = payload.get("diagram")
    if not isinstance(diagram, dict):
        return errors + ["diagram object is required"]
    for field in ("id", "title", "type"):
        if not diagram.get(field):
            errors.append(f"diagram.{field} is required")
    if diagram.get("type") not in SUPPORTED:
        errors.append(f"unsupported diagram.type: {diagram.get('type')}")
    if diagram.get("id") and not re.match(r"^[a-z0-9][a-z0-9-]*$", diagram["id"]):
        errors.append("diagram.id must be lowercase kebab-case")
    ids: set[str] = set()
    for key in ("elements", "nodes", "participants", "states", "steps"):
        for index, item in enumerate(diagram.get(key, [])):
            item_id = item.get("id")
            if not item_id or not item.get("label"):
                errors.append(f"diagram.{key}[{index}] requires id and label")
            elif item_id in ids:
                errors.append(f"duplicate element id: {item_id}")
            else:
                ids.add(item_id)
    for key in ("relationships", "edges", "messages", "transitions"):
        for index, relation in enumerate(diagram.get(key, [])):
            for endpoint in ("from", "to"):
                value = relation.get(endpoint)
                if not value:
                    errors.append(f"diagram.{key}[{index}].{endpoint} is required")
                elif value != "*" and value not in ids:
                    errors.append(f"diagram.{key}[{index}].{endpoint} references unknown id: {value}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    args = parser.parse_args()
    errors = validate(json.loads(args.model.read_text(encoding="utf-8")))
    if errors:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1
    print(f"PASS: {args.model.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
