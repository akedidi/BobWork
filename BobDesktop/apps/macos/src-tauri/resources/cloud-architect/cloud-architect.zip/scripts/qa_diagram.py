#!/usr/bin/env python3
"""Apply blocking structural checks to Mermaid, PlantUML, C4, and D2 SVG output."""

from __future__ import annotations

import argparse
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF]")


def number(value: str | None) -> float | None:
    if not value:
        return None
    match = re.match(r"([0-9.]+)", value)
    return float(match.group(1)) if match else None


def expected_labels(payload: dict) -> list[str]:
    model = payload.get("diagram", payload.get("architecture", payload))
    items = []
    for key in ("elements", "nodes", "participants", "states", "steps", "components"):
        for item in model.get(key, []):
            if item.get("label") and item.get("kind") != "end-decision":
                items.append(str(item["label"]))
    return items


def expected_icons(payload: dict) -> list[str]:
    model = payload.get("diagram", payload.get("architecture", payload))
    return [str(item["icon"]) for item in model.get("elements", []) if item.get("icon")]


def check(svg: Path, model: Path | None, max_ratio: float) -> list[str]:
    failures: list[str] = []
    raw = svg.read_text(encoding="utf-8")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        return [f"invalid SVG XML: {exc}"]
    if root.tag.split("}")[-1] != "svg":
        failures.append("root element is not SVG")
    viewbox = root.attrib.get("viewBox", "").split()
    width, height = number(root.attrib.get("width")), number(root.attrib.get("height"))
    if len(viewbox) == 4:
        width, height = float(viewbox[2]), float(viewbox[3])
    if not width or not height:
        failures.append("missing usable width/height or viewBox")
    elif max(width / height, height / width) > max_ratio:
        failures.append(f"aspect ratio exceeds {max_ratio}:1")
    if EMOJI.search("".join(root.itertext())):
        failures.append("emoji or pictogram substitute detected")
    if re.search(r'<(?:circle|path|line)\b[^>]*class=["\'][^"\']*\b(?:face|mouth)\b', raw):
        failures.append("Mermaid journey face marker detected; use neutral numeric score badges")
    if re.search(r'(?:href|xlink:href)=["\']https?://', raw, flags=re.I):
        failures.append("external image/resource hotlink detected")
    if "syntax error" in raw.lower() or "plantuml" in raw.lower() and "error" in raw.lower():
        failures.append("renderer error text detected")
    if model:
        payload = json.loads(model.read_text(encoding="utf-8"))
        model_type = payload.get("diagram", {}).get("type")
        if "<foreignObject" in raw and model_type != "journey":
            failures.append("unexpected foreignObject labels outside Mermaid journey")
        visible = " ".join(" ".join(root.itertext()).split()).lower()
        missing = [label for label in expected_labels(payload) if label.lower() not in visible]
        if missing:
            failures.append("missing model labels: " + ", ".join(missing[:8]))
        icon_keys = expected_icons(payload)
        embedded_images = len(re.findall(r'<image\b[^>]+(?:href|xlink:href)=["\']data:image/', raw, flags=re.I))
        if embedded_images < len(icon_keys):
            failures.append(f"missing embedded managed icons: expected {len(icon_keys)}, found {embedded_images}")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("svg", type=Path)
    parser.add_argument("--model", type=Path)
    parser.add_argument("--max-aspect-ratio", type=float, default=3.0)
    args = parser.parse_args()
    failures = check(args.svg, args.model, args.max_aspect_ratio)
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}", file=sys.stderr)
        return 1
    print(f"PASS: {args.svg.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
