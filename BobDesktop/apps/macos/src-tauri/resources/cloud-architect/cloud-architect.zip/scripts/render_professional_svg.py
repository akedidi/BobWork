#!/usr/bin/env python3
"""Render a curated 16:9 executive cloud architecture view with managed icons."""

from __future__ import annotations

import argparse
import base64
import json
import re
import textwrap
from pathlib import Path
from xml.sax.saxutils import escape


PLUGIN_ROOT = Path(__file__).resolve().parent.parent
ICON_MANIFEST = PLUGIN_ROOT / "assets" / "icon-manifest.json"

LAYOUT_HORIZONTAL = {
    "user": (65, 300, 190, 86),
    "app-gateway": (305, 235, 190, 86),
    "apim": (305, 410, 190, 86),
    "apim-gw-aks": (755, 235, 190, 86),
    "orchestrator": (985, 235, 200, 86),
    "tool-agents": (985, 420, 200, 86),
    "azure-openai": (1260, 235, 200, 86),
    "ai-search": (1260, 420, 200, 86),
    "cosmos-db": (1515, 190, 165, 78),
    "redis": (1690, 190, 165, 78),
    "key-vault": (1515, 330, 165, 78),
    "event-hubs": (1690, 330, 165, 78),
    "git-repo": (95, 785, 180, 82),
    "flux-cd": (325, 785, 180, 82),
    "acr": (555, 785, 180, 82),
    "entra-id": (820, 785, 180, 82),
    "prometheus": (1070, 785, 180, 82),
    "otel-collector": (1300, 785, 180, 82),
    "azure-monitor": (1530, 785, 205, 82),
}

LAYOUT_VERTICAL = {
    "user": (445, 175, 190, 86),
    "app-gateway": (445, 345, 190, 86),
    "apim": (445, 455, 190, 86),
    "apim-gw-aks": (120, 665, 190, 86),
    "orchestrator": (445, 665, 200, 86),
    "tool-agents": (760, 665, 200, 86),
    "azure-openai": (120, 875, 200, 86),
    "ai-search": (760, 875, 200, 86),
    "cosmos-db": (105, 1100, 165, 78),
    "redis": (310, 1100, 165, 78),
    "key-vault": (605, 1100, 165, 78),
    "event-hubs": (810, 1100, 165, 78),
    "git-repo": (65, 1430, 180, 82),
    "flux-cd": (285, 1430, 180, 82),
    "acr": (505, 1430, 180, 82),
    "entra-id": (725, 1430, 180, 82),
    "prometheus": (175, 1600, 180, 82),
    "otel-collector": (450, 1600, 180, 82),
    "azure-monitor": (725, 1600, 205, 82),
}

ICON_BY_ID = {
    "user": "generic.user",
    "app-gateway": "azure.application-gateway",
    "apim": "azure.api-management",
    "apim-gw-aks": "azure.api-management",
    "orchestrator": "generic.agent",
    "tool-agents": "generic.tools",
    "azure-openai": "azure.openai",
    "ai-search": "azure.ai-search",
    "cosmos-db": "azure.cosmos-db",
    "redis": "azure.redis",
    "key-vault": "azure.key-vault",
    "event-hubs": "azure.event-hubs",
    "git-repo": "generic.git-repository",
    "flux-cd": "generic.git-repository",
    "acr": "azure.container-registry",
    "entra-id": "azure.managed-identity",
    "prometheus": "generic.observability",
    "otel-collector": "generic.observability",
    "azure-monitor": "azure.monitor",
}

EDGE_SPECS = [
    ("user", "app-gateway", "HTTPS 443", "primary"),
    ("app-gateway", "apim", "WAF-filtered", "primary"),
    ("apim", "apim-gw-aks", "Private ingress", "primary"),
    ("apim-gw-aks", "orchestrator", "mTLS", "primary"),
    ("orchestrator", "tool-agents", "Tool dispatch", "primary"),
    ("orchestrator", "azure-openai", "LLM completion", "private"),
    ("tool-agents", "ai-search", "RAG query", "private"),
    ("orchestrator", "cosmos-db", "Session memory", "private"),
    ("orchestrator", "redis", "Response cache", "private"),
    ("orchestrator", "key-vault", "Managed identity", "private"),
    ("orchestrator", "event-hubs", "Audit events", "async"),
    ("git-repo", "flux-cd", "GitOps", "delivery"),
    ("flux-cd", "acr", "OCI artifacts", "delivery"),
    ("entra-id", "orchestrator", "Workload identity", "management"),
    ("prometheus", "otel-collector", "Metrics", "observability"),
    ("otel-collector", "azure-monitor", "OTLP", "observability"),
]

COLORS = {
    "primary": ("#2563EB", "arrow-primary"),
    "private": ("#6D28D9", "arrow-private"),
    "async": ("#7C3AED", "arrow-private"),
    "delivery": ("#059669", "arrow-delivery"),
    "management": ("#475569", "arrow-management"),
    "observability": ("#D97706", "arrow-observability"),
}

CUSTOM_PATHS_HORIZONTAL = {
    ("orchestrator", "cosmos-db"): (
        "M 1185 250 V 145 H 1597 V 190",
        1385,
        134,
    ),
    ("orchestrator", "redis"): (
        "M 1185 262 V 118 H 1772 V 190",
        1510,
        107,
    ),
    ("orchestrator", "key-vault"): (
        "M 1185 286 H 1205 V 365 H 1515",
        1370,
        354,
    ),
    ("orchestrator", "event-hubs"): (
        "M 1185 300 H 1195 V 392 H 1690 V 369",
        1500,
        381,
    ),
    ("entra-id", "orchestrator"): (
        "M 910 785 V 665 H 700 V 278 H 985",
        805,
        654,
    ),
}


def safe_id(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]", "-", value)


def load_architecture(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))["architecture"]


def icon_data_uri(key: str, catalog: dict) -> str:
    relative = Path(catalog["assets"][key]["path"])
    payload = (PLUGIN_ROOT / "assets" / relative).read_bytes()
    return "data:image/svg+xml;base64," + base64.b64encode(payload).decode("ascii")


def component_label(component: dict) -> str:
    labels = {
        "app-gateway": "Application Gateway\n+ WAF",
        "apim": "Azure API\nManagement",
        "apim-gw-aks": "APIM self-hosted\ngateway",
        "orchestrator": "Agent\nOrchestrator",
        "tool-agents": "Specialized\nTool Agents",
        "azure-openai": "Azure OpenAI\nService",
        "ai-search": "Azure AI Search\nRAG",
        "cosmos-db": "Cosmos DB",
        "redis": "Azure Cache\nfor Redis",
        "key-vault": "Key Vault",
        "event-hubs": "Event Hubs",
        "git-repo": "Git Repository",
        "flux-cd": "Flux v2",
        "acr": "Container\nRegistry",
        "entra-id": "Microsoft\nEntra ID",
        "prometheus": "Prometheus\n+ Grafana",
        "otel-collector": "OpenTelemetry\nCollector",
        "azure-monitor": "Azure Monitor\n+ Log Analytics",
        "user": "Clients &\nApplications",
    }
    if component["id"] in labels:
        return labels[component["id"]]
    return "\n".join(textwrap.wrap(component.get("label", component["id"]), width=20)[:2])


def node_svg(component: dict, catalog: dict, layout: dict) -> str:
    component_id = component["id"]
    x, y, width, height = layout[component_id]
    icon_key = ICON_BY_ID[component_id]
    icon = icon_data_uri(icon_key, catalog)
    lines = component_label(component).split("\n")
    icon_size = 40 if height >= 82 else 34
    icon_x = x + 14
    icon_y = y + (height - icon_size) / 2
    text_x = icon_x + icon_size + 12
    first_y = y + height / 2 - (len(lines) - 1) * 9
    tspans = "".join(
        f'<tspan x="{text_x:.0f}" y="{first_y + index * 19:.0f}">{escape(line)}</tspan>'
        for index, line in enumerate(lines)
    )
    return (
        f'<g id="node-{safe_id(component_id)}" class="node">'
        f'<rect x="{x}" y="{y}" width="{width}" height="{height}" rx="12" '
        'fill="#FFFFFF" stroke="#64748B" stroke-width="2" filter="url(#card-shadow)"/>'
        f'<image href="{icon}" x="{icon_x}" y="{icon_y:.0f}" '
        f'width="{icon_size}" height="{icon_size}" preserveAspectRatio="xMidYMid meet"/>'
        f'<text class="node-label" font-size="14" font-weight="600" fill="#0F172A">{tspans}</text>'
        '</g>'
    )


def edge_path(source: tuple[int, int, int, int], target: tuple[int, int, int, int]) -> tuple[str, float, float]:
    sx, sy, sw, sh = source
    tx, ty, tw, th = target
    source_center = (sx + sw / 2, sy + sh / 2)
    target_center = (tx + tw / 2, ty + th / 2)
    if tx >= sx + sw:
        start_x, start_y = sx + sw, source_center[1]
        end_x, end_y = tx, target_center[1]
        middle_x = (start_x + end_x) / 2
        path = f"M {start_x} {start_y} H {middle_x} V {end_y} H {end_x}"
        return path, middle_x, min(start_y, end_y) + abs(end_y - start_y) / 2 - 8
    if ty >= sy + sh:
        start_x, start_y = source_center[0], sy + sh
        end_x, end_y = target_center[0], ty
        middle_y = (start_y + end_y) / 2
        path = f"M {start_x} {start_y} V {middle_y} H {end_x} V {end_y}"
        return path, (start_x + end_x) / 2, middle_y - 8
    start_x, start_y = source_center[0], sy
    end_x, end_y = target_center[0], ty + th
    middle_y = (start_y + end_y) / 2
    path = f"M {start_x} {start_y} V {middle_y} H {end_x} V {end_y}"
    return path, (start_x + end_x) / 2, middle_y - 8


def edge_svg(source_id: str, target_id: str, label: str, kind: str, index: int, layout: dict, custom_paths: dict) -> str:
    path, label_x, label_y = custom_paths.get(
        (source_id, target_id),
        edge_path(layout[source_id], layout[target_id]),
    )
    color, marker = COLORS[kind]
    dash = ' stroke-dasharray="8 6"' if kind in {"async", "management", "observability"} else ""
    return (
        f'<g id="edge-{index}" class="edge">'
        f'<path d="{path}" fill="none" stroke="{color}" stroke-width="2.5" '
        f'marker-end="url(#{marker})"{dash}/>'
        f'<text x="{label_x:.0f}" y="{label_y:.0f}" text-anchor="middle" '
        f'font-size="12" font-weight="600" fill="{color}" '
        'paint-order="stroke" stroke="#FFFFFF" stroke-width="5" stroke-linejoin="round">'
        f'{escape(label)}</text>'
        '</g>'
    )


def boundary(x: int, y: int, width: int, height: int, label: str, stroke: str, fill: str) -> str:
    return (
        f'<g class="boundary"><rect x="{x}" y="{y}" width="{width}" height="{height}" '
        f'rx="18" fill="{fill}" stroke="{stroke}" stroke-width="2"/>'
        f'<text x="{x + 18}" y="{y + 30}" font-size="16" font-weight="700" '
        f'fill="{stroke}">{escape(label)}</text></g>'
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--view-model", type=Path)
    parser.add_argument("--orientation", choices=["horizontal", "vertical"], default="horizontal")
    args = parser.parse_args()

    horizontal = args.orientation == "horizontal"
    layout = LAYOUT_HORIZONTAL if horizontal else LAYOUT_VERTICAL
    custom_paths = CUSTOM_PATHS_HORIZONTAL if horizontal else {}
    canvas_width, canvas_height = (1920, 1080) if horizontal else (1080, 1920)

    architecture = load_architecture(args.model)
    components_by_id = {
        component["id"]: component for component in architecture.get("components", [])
    }
    selected_ids = [component_id for component_id in layout if component_id in components_by_id]
    selected_components = []
    for component_id in selected_ids:
        component = dict(components_by_id[component_id])
        component["icon"] = ICON_BY_ID[component_id]
        component["render_path"] = component_id
        selected_components.append(component)
    selected_set = set(selected_ids)
    relationships = [
        {
            "id": f"executive-{index + 1:02d}",
            "from": source,
            "to": target,
            "label": label,
            "classification": kind,
        }
        for index, (source, target, label, kind) in enumerate(EDGE_SPECS)
        if source in selected_set and target in selected_set
    ]
    catalog = json.loads(ICON_MANIFEST.read_text(encoding="utf-8"))

    definitions = """
    <defs>
      <filter id="card-shadow" x="-20%" y="-20%" width="140%" height="150%">
        <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#0F172A" flood-opacity=".12"/>
      </filter>
      <marker id="arrow-primary" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#2563EB"/></marker>
      <marker id="arrow-private" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#6D28D9"/></marker>
      <marker id="arrow-delivery" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#059669"/></marker>
      <marker id="arrow-management" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#475569"/></marker>
      <marker id="arrow-observability" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#D97706"/></marker>
    </defs>
    """
    boundaries = (
        [
            boundary(35, 135, 235, 505, "Consumers", "#64748B", "#F8FAFC"),
            boundary(280, 135, 230, 505, "Secure ingress", "#0078D4", "#F0F8FF"),
            boundary(730, 135, 480, 505, "AKS — agent runtime", "#326CE5", "#EEF2FF"),
            boundary(1225, 135, 255, 505, "Azure AI", "#0078D4", "#F0F8FF"),
            boundary(1490, 135, 390, 505, "Private data services", "#6D28D9", "#FAF5FF"),
            boundary(35, 700, 1845, 245, "Cross-cutting platform capabilities", "#475569", "#F8FAFC"),
        ] if horizontal else [
            boundary(40, 130, 1000, 150, "Consumers", "#64748B", "#F8FAFC"),
            boundary(40, 310, 1000, 255, "Secure ingress", "#0078D4", "#F0F8FF"),
            boundary(40, 595, 1000, 385, "AKS and Azure AI runtime", "#326CE5", "#EEF2FF"),
            boundary(40, 1010, 1000, 280, "Private data services", "#6D28D9", "#FAF5FF"),
            boundary(40, 1340, 1000, 390, "Cross-cutting platform capabilities", "#475569", "#F8FAFC"),
        ]
    )
    edges = [
        edge_svg(source, target, label, kind, index, layout, custom_paths)
        for index, (source, target, label, kind) in enumerate(EDGE_SPECS, start=1)
        if source in selected_set and target in selected_set
    ]
    nodes = [node_svg(components_by_id[component_id], catalog, layout) for component_id in selected_ids]
    title = escape(architecture.get("name", "Cloud architecture"))
    version = escape(str(architecture.get("version", "")))
    status = escape(str(architecture.get("status", "")).upper())
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{canvas_width}" height="{canvas_height}" '
        f'viewBox="0 0 {canvas_width} {canvas_height}" role="img" aria-labelledby="title description">'
        f'<title id="title">{title} — Executive architecture</title>'
        '<desc id="description">Screen-sized 16:9 executive view of the primary runtime, '
        'private Azure services, delivery, identity, and observability capabilities.</desc>'
        f'<rect width="{canvas_width}" height="{canvas_height}" fill="#FFFFFF"/>'
        + definitions
        + f'<text x="40" y="58" font-size="30" font-weight="750" fill="#0F172A">{title}</text>'
        + f'<text x="40" y="91" font-size="15" fill="#475569">Executive view · {"16:9 landscape" if horizontal else "9:16 portrait"} · '
        f'Primary runtime + cross-cutting capabilities · v{version} · {status}</text>'
        + '<g id="boundaries">'
        + "".join(boundaries)
        + '</g><g id="connectors">'
        + "".join(edges)
        + '</g><g id="components">'
        + "".join(nodes)
        + '</g>'
        + f'<g id="legend"><line x1="55" y1="{canvas_height - 85}" x2="105" y2="{canvas_height - 85}" stroke="#2563EB" stroke-width="3"/>'
        + f'<text x="118" y="{canvas_height - 80}" font-size="13" fill="#334155">Primary runtime</text>'
        + f'<line x1="285" y1="{canvas_height - 85}" x2="335" y2="{canvas_height - 85}" stroke="#6D28D9" stroke-width="3"/>'
        + f'<text x="348" y="{canvas_height - 80}" font-size="13" fill="#334155">Private Link</text>'
        + f'<line x1="485" y1="{canvas_height - 85}" x2="535" y2="{canvas_height - 85}" stroke="#059669" stroke-width="3"/>'
        + f'<text x="548" y="{canvas_height - 80}" font-size="13" fill="#334155">Delivery</text>'
        + f'<line x1="665" y1="{canvas_height - 85}" x2="715" y2="{canvas_height - 85}" stroke="#D97706" stroke-width="3" stroke-dasharray="8 6"/>'
        + f'<text x="728" y="{canvas_height - 80}" font-size="13" fill="#334155">Observability</text>'
        + f'<text x="{canvas_width - 40}" y="{canvas_height - 35}" text-anchor="end" font-size="13" fill="#64748B">'
        + 'Official Azure SVG icons · Embedded locally · No external hotlinks</text></g>'
        + '</svg>'
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(svg, encoding="utf-8")
    view_model = args.view_model or args.output.with_suffix(".model.json")
    view_architecture = {
        **architecture,
        "name": f"{architecture.get('name', 'Architecture')} — Executive view",
        "components": selected_components,
        "relationships": relationships,
        "boundaries": [],
        "diagramView": {
            "id": "executive",
            "targetCanvas": f"{canvas_width}x{canvas_height}",
            "readingDirection": "left-to-right" if horizontal else "top-to-bottom",
            "primaryStory": "client to secure ingress to AKS agents to private Azure AI and data services",
            "officialIconsRequired": True,
            "layout": "deterministic-fixed",
        },
    }
    view_model.write_text(
        json.dumps({"architecture": view_architecture}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "svg": str(args.output.resolve()),
                "model": str(view_model.resolve()),
                "components": len(selected_components),
                "relationships": len(relationships),
                "icons": len(selected_components),
                "canvas": f"{canvas_width}x{canvas_height}",
                "orientation": args.orientation,
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
