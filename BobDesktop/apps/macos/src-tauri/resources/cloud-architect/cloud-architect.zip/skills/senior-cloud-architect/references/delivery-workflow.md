# Delivery workflow

## 1. Frame

Identify the decision, audience, scope, constraints, evidence, required formats, and acceptance criteria. Record assumptions instead of silently filling gaps.

## 2. Model

Create the architecture model. For AWS, Azure, Google Cloud, or IBM Cloud, select and reverify the official Well-Architected framework, architecture catalog, foundation guidance, and applicable blueprints; record them in `framework_alignment`. Validate IDs, component relationships, requirements, risks, framework alignment, and evidence before drawing.

## 3. Decide

Document material options and tradeoffs. Compare the design with the nearest official reference architectures and decide whether to adopt, adapt, reference, or reject applicable blueprints. Create an ADR when a decision is expensive to reverse, affects several teams, changes a trust boundary, sets a platform standard, or materially deviates from an official foundation or blueprint.

## 4. Visualize

Choose the smallest set of complementary views. Render each diagram, inspect the full-size output, correct layout defects, and rerender.

## 5. Document

Choose the artifact for the audience:

- executive brief or deck for sponsorship and funding;
- HLD for cross-team design agreement;
- LLD for implementers and operators;
- ADR for durable decisions;
- migration plan for sequencing and cutover;
- DR plan and runbook for recovery operations;
- review scorecard for assurance and remediation.

## 6. Cross-check

Confirm that component names, environments, data flows, protocols, requirements, decisions, risks, framework findings, blueprint decisions, deviations, and evidence match across every artifact.

## 7. Render and inspect

- Diagrams: inspect SVG or PNG at 100% and presentation scale.
- DOCX: render every page to PNG and inspect.
- PDF: render every page and inspect.
- PPTX: render every slide, run overflow checks, and inspect full-size slides.

## 8. Deliver

Provide final artifacts, editable sources, model, evidence list, validation status, and known limitations. Do not deliver QA intermediates unless requested.
