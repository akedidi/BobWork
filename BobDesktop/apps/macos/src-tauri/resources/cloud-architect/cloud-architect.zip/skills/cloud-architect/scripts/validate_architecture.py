#!/usr/bin/env python3
"""Validate the Cloud Architect source-of-truth model."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ID_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
REQUIRED_LISTS = ("components", "relationships", "decisions", "risks")
PROVIDER_ALIASES = {
    "aws": "aws",
    "azure": "azure",
    "gcp": "gcp",
    "google": "gcp",
    "google-cloud": "gcp",
    "ibm": "ibm",
    "ibm-cloud": "ibm",
}
FRAMEWORK_CATEGORIES = {
    "framework", "reference-architecture", "blueprint", "implementation", "diagram-assets"
}
FRAMEWORK_STATUSES = {
    "not-reviewed", "aligned", "partial", "gap", "accepted-deviation", "not-applicable"
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path, help="Architecture model in JSON or YAML")
    parser.add_argument("--strict", action="store_true", help="Treat warnings as errors")
    parser.add_argument("--json", action="store_true", dest="json_output", help="Emit machine-readable JSON")
    return parser.parse_args()


def load_model(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        payload = json.loads(text)
    elif path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise RuntimeError("YAML input requires PyYAML; use JSON or install PyYAML") from exc
        payload = yaml.safe_load(text)
    else:
        raise ValueError("Model extension must be .json, .yaml, or .yml")
    if not isinstance(payload, dict):
        raise ValueError("Model root must be an object")
    return payload


def validate(payload: dict[str, Any]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    architecture = payload.get("architecture")
    if not isinstance(architecture, dict):
        return ["architecture must be an object"], warnings

    for field in ("name", "version", "status"):
        if not isinstance(architecture.get(field), str) or not architecture[field].strip():
            errors.append(f"architecture.{field} must be a non-empty string")

    if not isinstance(architecture.get("requirements"), dict):
        errors.append("architecture.requirements must be an object")

    for field in REQUIRED_LISTS:
        if not isinstance(architecture.get(field), list):
            errors.append(f"architecture.{field} must be an array")

    if errors:
        return errors, warnings

    ids: dict[str, str] = {}
    boundaries = architecture.get("boundaries", [])
    if not isinstance(boundaries, list):
        errors.append("architecture.boundaries must be an array")
        boundaries = []

    def register(items: list[Any], section: str) -> None:
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                errors.append(f"{section}[{index}] must be an object")
                continue
            item_id = item.get("id")
            if not isinstance(item_id, str) or not ID_RE.fullmatch(item_id):
                errors.append(f"{section}[{index}].id must use lowercase hyphen-case")
                continue
            if item_id in ids:
                errors.append(f"duplicate id '{item_id}' in {section} and {ids[item_id]}")
            else:
                ids[item_id] = section

    register(boundaries, "boundaries")
    for field in REQUIRED_LISTS:
        register(architecture[field], field)
    evidence = architecture.get("evidence", [])
    if isinstance(evidence, list):
        register(evidence, "evidence")
    else:
        errors.append("architecture.evidence must be an array when present")
    framework_alignment = architecture.get("framework_alignment", [])
    if isinstance(framework_alignment, list):
        register(framework_alignment, "framework_alignment")
    else:
        errors.append("architecture.framework_alignment must be an array when present")
        framework_alignment = []

    boundary_ids = {item.get("id") for item in boundaries if isinstance(item, dict)}
    component_ids = {item.get("id") for item in architecture["components"] if isinstance(item, dict)}
    decision_ids = {item.get("id") for item in architecture["decisions"] if isinstance(item, dict)}
    evidence_ids = {item.get("id") for item in evidence if isinstance(item, dict)}

    for boundary in boundaries:
        if not isinstance(boundary, dict):
            continue
        parent = boundary.get("parent")
        if parent is not None and parent not in boundary_ids:
            errors.append(f"boundary '{boundary.get('id')}' references unknown parent '{parent}'")

    for component in architecture["components"]:
        if not isinstance(component, dict):
            continue
        for field in ("label", "type"):
            if not isinstance(component.get(field), str) or not component[field].strip():
                errors.append(f"component '{component.get('id')}' requires {field}")
        boundary = component.get("boundary")
        if boundary is not None and boundary not in boundary_ids:
            errors.append(f"component '{component.get('id')}' references unknown boundary '{boundary}'")

    flow_fields = ("protocol", "encryption", "classification", "criticality", "failure_behavior")
    for relationship in architecture["relationships"]:
        if not isinstance(relationship, dict):
            continue
        source = relationship.get("from")
        target = relationship.get("to")
        if source not in component_ids:
            errors.append(f"relationship '{relationship.get('id')}' references unknown source '{source}'")
        if target not in component_ids:
            errors.append(f"relationship '{relationship.get('id')}' references unknown target '{target}'")
        if source == target:
            warnings.append(f"relationship '{relationship.get('id')}' is a self-loop")
        if relationship.get("criticality") in {"high", "critical"}:
            missing = [field for field in flow_fields if not relationship.get(field)]
            if missing:
                warnings.append(
                    f"critical relationship '{relationship.get('id')}' lacks {', '.join(missing)}"
                )

    requirements = architecture.get("requirements", {})
    for field in ("availability", "rto", "rpo", "data_residency", "cost_ceiling"):
        if not requirements.get(field) or str(requirements[field]).upper() == "TBD":
            warnings.append(f"requirement '{field}' is unresolved")

    for assumption in architecture.get("assumptions", []):
        if not isinstance(assumption, str) or not assumption.strip():
            errors.append("assumptions must contain non-empty strings")

    registry_path = Path(__file__).resolve().parent.parent / "assets" / "official-provider-guidance.json"
    registry: dict[str, Any] = {}
    try:
        registry = json.loads(registry_path.read_text(encoding="utf-8")).get("providers", {})
    except (OSError, json.JSONDecodeError):
        warnings.append("official provider guidance registry could not be loaded")

    target_providers = {
        PROVIDER_ALIASES.get(str(provider).strip().lower())
        for provider in architecture.get("cloud_providers", [])
    }
    target_providers.discard(None)
    alignment_providers: set[str] = set()
    for index, item in enumerate(framework_alignment):
        if not isinstance(item, dict):
            errors.append(f"framework_alignment[{index}] must be an object")
            continue
        provider = PROVIDER_ALIASES.get(str(item.get("provider", "")).strip().lower())
        if provider not in {"aws", "azure", "gcp", "ibm"}:
            errors.append(f"framework_alignment[{index}].provider must be aws, azure, gcp, or ibm")
            continue
        alignment_providers.add(provider)
        if item.get("category") not in FRAMEWORK_CATEGORIES:
            errors.append(f"framework_alignment[{index}].category is invalid")
        if item.get("status") not in FRAMEWORK_STATUSES:
            errors.append(f"framework_alignment[{index}].status is invalid")
        for field in ("name", "source", "retrieved"):
            if not isinstance(item.get(field), str) or not item[field].strip():
                errors.append(f"framework_alignment[{index}].{field} must be a non-empty string")
        source = str(item.get("source", ""))
        host = urlparse(source).hostname or ""
        official_domains = registry.get(provider, {}).get("official_domains", [])
        if official_domains and not any(host == domain or host.endswith("." + domain) for domain in official_domains):
            warnings.append(
                f"framework_alignment '{item.get('id')}' source host '{host}' is not in the official {provider} registry"
            )
        for component_id in item.get("components", []):
            if component_id not in component_ids:
                errors.append(f"framework_alignment '{item.get('id')}' references unknown component '{component_id}'")
        for decision_id in item.get("decisions", []):
            if decision_id not in decision_ids:
                errors.append(f"framework_alignment '{item.get('id')}' references unknown decision '{decision_id}'")
        for evidence_id in item.get("evidence", []):
            if evidence_id not in evidence_ids:
                warnings.append(f"framework_alignment '{item.get('id')}' references unknown evidence '{evidence_id}'")
        if item.get("category") in {"blueprint", "implementation", "reference-architecture"} and not item.get("reuse_decision"):
            warnings.append(f"framework_alignment '{item.get('id')}' lacks a reuse_decision")

    for provider in sorted(target_providers - alignment_providers):
        warnings.append(f"provider '{provider}' has no official framework_alignment entry")

    if not architecture.get("evidence"):
        warnings.append("no evidence entries are recorded")
    return errors, warnings


def main() -> int:
    args = parse_args()
    try:
        payload = load_model(args.model)
        errors, warnings = validate(payload)
    except (OSError, ValueError, json.JSONDecodeError, RuntimeError) as exc:
        errors, warnings = [str(exc)], []

    result = {
        "model": str(args.model),
        "valid": not errors and not (args.strict and warnings),
        "errors": errors,
        "warnings": warnings,
    }
    if args.json_output:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        for error in errors:
            print(f"ERROR: {error}")
        for warning in warnings:
            print(f"WARNING: {warning}")
        print(f"RESULT: {'PASS' if result['valid'] else 'FAIL'}")
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
