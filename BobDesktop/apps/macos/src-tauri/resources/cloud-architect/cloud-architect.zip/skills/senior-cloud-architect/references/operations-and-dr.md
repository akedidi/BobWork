# Operations and disaster recovery

## Operability

Define service-level indicators, objectives, alerts, dashboards, logs, traces, metrics, ownership, escalation, capacity signals, deployment health, configuration drift, and runbook links.

## Failure analysis

For each critical path, identify failure domains, dependency timeouts, retry behavior, circuit breaking, queueing, backpressure, idempotency, degraded modes, and user-visible impact.

## Recovery design

Select backup and recovery, pilot light, warm standby, or active-active only after confirming business RTO, RPO, consistency, residency, and cost constraints. Document:

- authoritative data source and replication semantics;
- backup scope, immutability, encryption, retention, and restore testing;
- traffic failover and failback controls;
- secrets, certificates, DNS, IAM, configuration, and infrastructure recovery;
- recovery dependencies and manual decision points;
- maximum tolerable data loss and validation checks.

## Test contract

Define scenario, preconditions, blast radius, owners, stop conditions, measurements, evidence, rollback, and remediation. Never claim an RTO or RPO is achieved without a measured exercise or equivalent evidence.
