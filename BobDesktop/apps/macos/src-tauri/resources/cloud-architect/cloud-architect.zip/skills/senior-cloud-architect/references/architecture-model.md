# Architecture model

Use one structured model as the source of truth for diagrams, documents, and reviews.

## Confidence classes

- `facts`: verified inputs or evidence-backed observations.
- `assumptions`: provisional statements that materially affect the design.
- `recommendations`: proposed choices with rationale and alternatives.
- `open_questions`: unresolved items that could change the design.

Do not merge these classes. Promote an assumption to a fact only after evidence is available.

## Stable identifiers

Give environments, boundaries, components, relationships, decisions, risks, and evidence stable lowercase identifiers. Keep IDs stable across revisions so documents and diagrams can cross-reference them.

## Required model areas

- Identity: name, version, status, scope, audience, owners, and review date.
- Requirements: availability, latency, RTO, RPO, security, compliance, data residency, scale, and cost.
- Deployment: providers, regions, environments, accounts/projects/subscriptions, networks, zones, and clusters.
- Components: purpose, type, provider service, boundary, data, scaling, state, and owner.
- Relationships: endpoints, direction, protocol, port, encryption, data classification, criticality, and failure behavior.
- Decisions: status, rationale, alternatives, consequences, and evidence.
- Risks: likelihood, impact, mitigation, contingency, and owner.
- Evidence: authoritative source, retrieval date, affected claims, and freshness window.
- Framework alignment: provider, official framework or blueprint, category, source, retrieval date, applicability, pillar or design area, status, mapped components and decisions, evidence, gap, remediation, deviation, and blueprint reuse decision.

## Consistency rules

- Every relationship endpoint must reference a known component.
- Every component boundary must reference a known boundary.
- Every critical flow must declare protocol, encryption, classification, and failure behavior.
- Requirements and success criteria must come from the engagement, not plugin defaults.
- Every material recommendation must link to a decision or risk.
- Every AWS, Azure, Google Cloud, or IBM Cloud architecture review must record at least one provider-native `framework_alignment` entry or explicitly state why the official framework is not applicable.
- A reference architecture or blueprint reuse claim must state whether the asset is descriptive or deployable and record `adopt`, `adapt`, `reference-only`, or `reject` with rationale.
- Diagrams may omit detail for readability, but must never contradict the model.

Start from [../assets/architecture.example.json](../assets/architecture.example.json). Run `../scripts/validate_architecture.py` after material changes.
