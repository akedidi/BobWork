#!/usr/bin/env python3
"""Generate an editable D2 topology from an architecture model."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


def load(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        payload = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise RuntimeError("YAML input requires PyYAML; use JSON or install PyYAML") from exc
        payload = yaml.safe_load(text)
    return payload["architecture"]


def safe_id(value: str) -> str:
    result = re.sub(r"[^a-zA-Z0-9_]", "_", value)
    return f"n_{result}" if result[:1].isdigit() else result


def d2_string(value: Any) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    architecture = load(args.model)
    boundaries = architecture.get("boundaries", [])
    components = architecture.get("components", [])
    relationships = architecture.get("relationships", [])
    component_paths: dict[str, str] = {}
    lines = [
        "vars: {",
        "  d2-config: {",
        "    layout-engine: elk",
        "    theme-id: 0",
        "  }",
        "}",
        "direction: right",
        "",
    ]

    by_boundary: dict[Any, list[dict[str, Any]]] = {}
    for component in components:
        by_boundary.setdefault(component.get("boundary"), []).append(component)

    for boundary in boundaries:
        boundary_id = safe_id(boundary["id"])
        lines.append(f"{boundary_id}: {d2_string(boundary.get('label', boundary['id']))} {{")
        lines.append("  style.fill: \"#F8FAFC\"")
        lines.append("  style.stroke: \"#94A3B8\"")
        for component in by_boundary.get(boundary["id"], []):
            node_id = safe_id(component["id"])
            component_paths[component["id"]] = f"{boundary_id}.{node_id}"
            lines.append(f"  {node_id}: {d2_string(component.get('label', component['id']))} {{")
            icon = component.get("icon")
            if icon:
                lines.append(f"    icon: {d2_string(icon)}")
            lines.append("    style.fill: \"#FFFFFF\"")
            lines.append("    style.stroke: \"#475569\"")
            lines.append("  }")
        lines.append("}")
        lines.append("")

    for component in by_boundary.get(None, []):
        node_id = safe_id(component["id"])
        component_paths[component["id"]] = node_id
        lines.append(f"{node_id}: {d2_string(component.get('label', component['id']))}")
    lines.append("")

    for relationship in relationships:
        source = component_paths.get(relationship["from"], safe_id(relationship["from"]))
        target = component_paths.get(relationship["to"], safe_id(relationship["to"]))
        label = d2_string(relationship.get("label", ""))
        lines.append(f"{source} -> {target}: {label}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
