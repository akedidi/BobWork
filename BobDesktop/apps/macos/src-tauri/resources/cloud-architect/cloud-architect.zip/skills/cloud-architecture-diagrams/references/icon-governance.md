# Icon governance

Use provider icons as technical symbols with managed provenance, not decorative clip art.

## Authoritative sources

- AWS Architecture Icons: `https://aws.amazon.com/architecture/icons/`
- Azure Architecture Icons: `https://learn.microsoft.com/azure/architecture/icons/`
- Google Cloud product icons: `https://cloud.google.com/icons`
- IBM Cloud Architecture Icons and Stencils: `https://github.com/IBM-Cloud/architecture-icons`
- Kubernetes community icons: `https://github.com/kubernetes/community/tree/master/icons`
- CNCF project artwork: use the relevant official project or CNCF branding source.

## Retrieval

1. Retrieve only the icons needed for the current deliverable.
2. Prefer SVG, keep the original filename, and avoid lossy conversion.
3. Record source URL, retrieval date, provider release/version when available, and SHA-256.
4. Store the resolved local path in the architecture model or task asset manifest.
5. Recheck freshness before a final external publication.

## Usage

- Follow provider trademark and icon usage terms.
- Keep the product name next to the icon.
- Do not crop, rotate, stretch, recolor, or repurpose provider icons.
- Keep one current icon generation per provider in a diagram set.
- Use provider icons for services and neutral shapes for internal applications, actors, decisions, risks, and abstract concepts.

## Offline behavior

Do not hotlink icons in final artifacts. Copy permitted assets into the task's output bundle. If retrieval is unavailable, use clearly labeled generic symbols and record the missing asset as a limitation.
