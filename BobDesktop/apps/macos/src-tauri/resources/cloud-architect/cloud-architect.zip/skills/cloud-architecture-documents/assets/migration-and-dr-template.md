# Migration and Recovery Plan: [System]

## Objectives and success criteria

Define business outcome, scope, RTO, RPO, downtime, data integrity, security, and rollback criteria.

## Preconditions and dependencies

List environments, connectivity, identity, data, tooling, approvals, capacity, backup, observability, and staffing prerequisites.

## Migration waves

For each wave, record scope, owner, dependencies, entry criteria, actions, validation, exit criteria, rollback trigger, and communications.

## Data migration

Define authority, replication or transfer method, consistency, validation, reconciliation, freeze windows, encryption, retention, and rollback.

## Cutover workflow

Show decision authority, step sequence, checkpoints, traffic changes, validation, monitoring, stop conditions, and rollback.

## Recovery strategy

Define failure detection, declaration authority, recovery environment, data recovery, infrastructure recovery, traffic failover, validation, communications, and failback.

## Test plan

Record scenarios, blast radius, owners, schedule, measurements, evidence, stop conditions, rollback, and remediation.

## Risks and contingencies

Record likelihood, impact, prevention, contingency, owner, and residual risk.

## Evidence and sign-off

List test results, approvals, unresolved exceptions, and final decision records.
