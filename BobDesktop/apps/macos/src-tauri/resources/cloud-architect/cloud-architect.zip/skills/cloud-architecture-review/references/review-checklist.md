# Architecture review checklist

## Scope and requirements

- Business outcome, audience, scope, owners, constraints, and decision stage are explicit.
- Availability, latency, scale, RTO, RPO, security, compliance, residency, cost, and delivery requirements are sourced and testable.
- Facts, assumptions, recommendations, and open questions are separated.
- Target providers, official framework versions or retrieval dates, applicable lenses or perspectives, and review scope are explicit.

## Official framework and blueprint alignment

- Each provider is assessed against its own current Well-Architected framework before cross-provider normalization.
- Applicable pillars, workload lenses, service guides, perspectives, industry guidance, and regulatory overlays are selected from official sources.
- The nearest official reference architectures are identified and compared with the proposed design.
- Foundation, landing-zone, accelerator, solution, or deployable-architecture options are evaluated before recommending a custom platform.
- Every official asset is classified as framework, reference architecture, blueprint, implementation, or diagram asset.
- Blueprint decisions use `adopt`, `adapt`, `reference-only`, or `reject` with rationale, version, source, deviations, and ownership.
- Framework status is supported by architecture evidence and never inferred from checklist completion alone.

## Design and dependencies

- Component responsibilities, ownership, state, scaling, lifecycle, and dependencies are clear.
- Critical paths show protocols, timeouts, retries, idempotency, backpressure, and degraded behavior.
- Alternatives and consequences exist for material decisions.

## Security and data

- Identity, authorization, secrets, encryption, trust zones, ingress, egress, private connectivity, logging, and audit are designed.
- Data classification, authority, residency, retention, deletion, replication, backup, and restore are coherent.
- Supply-chain, image, dependency, vulnerability, and configuration controls are addressed.

## Reliability and operations

- Failure domains, redundancy, capacity, quotas, health, degradation, recovery, failover, failback, and rollback are explicit.
- SLOs, telemetry, alerting, runbooks, ownership, escalation, maintenance, patching, and lifecycle are defined.
- Claimed RTO, RPO, availability, or failover performance has measured evidence or is labeled as a target.

## Cost and sustainability

- Estimates state workload, region, pricing date, commitment, growth, support, networking, storage, observability, and operational assumptions.
- Cost ranges, drivers, uncertainty, budgets, and optimization tradeoffs are visible.
- Right-sizing and sustainability recommendations do not compromise required reliability or performance.

## Migration

- Discovery, dependency mapping, waves, coexistence, data movement, validation, cutover, rollback, communication, and exit criteria are defined.
- Owners, decision gates, stop conditions, and evidence are assigned.

## Artifacts

- Model, inventory, diagrams, ADRs, documents, and plans agree.
- Diagrams and office artifacts passed their render and inspection gates.
- Provider icons and terminology are current and used according to official guidance.
- No placeholders, phantom tools, fabricated evidence, or unsupported claims remain.
