# Document contract

## Narrative

- Lead with the decision, recommendation, and material consequence.
- Distinguish current state, target state, transition state, and rejected alternatives.
- Keep implementation details out of executive sections unless they change cost, risk, timing, or control.
- Place assumptions and unresolved decisions where reviewers will see them.

## Evidence

- Cite official primary sources for current provider claims.
- Record retrieval dates for volatile information.
- Link claims to evidence and decisions to alternatives.
- Never cite a static plugin matrix as authoritative provider evidence.

## Visuals

- Use diagrams to explain relationships, sequence, deployment, flow, and failure behavior.
- Keep figure captions and visuals together.
- Confirm embedded SVG or raster output remains legible at the final size.
- Reinspect diagrams after DOCX, PDF, or PPTX conversion.

## Tables

Use tables for component inventories, decision comparisons, requirements, interfaces, risks, controls, migration waves, and test cases. Use prose, bullets, or callouts for explanation and rationale.

## Quality gate

- Render the complete artifact, not a sample page or slide.
- Inspect every page or slide at full size.
- Fix clipping, overlaps, wrapping, missing glyphs, awkward breaks, inconsistent spacing, and unreadable figures.
- Validate page numbers, headings, captions, cross-references, headers, footers, and source links.
