# Official framework alignment

Assessment date: [date]  
Architecture version: [version]  
Providers in scope: [AWS | Azure | Google Cloud | IBM Cloud]  
Assessed workload and environments: [scope]  
Evidence cutoff: [date]

## Selected official guidance

| Provider | Official framework | Lens / perspective / workload guidance | Architecture catalog examples | Blueprint or landing zone | Retrieval date |
|---|---|---|---|---|---|

## Pillar and design-area assessment

| ID | Provider | Pillar or design area | Status | Supporting components and decisions | Gap or deviation | Remediation and owner | Evidence |
|---|---|---|---|---|---|---|---|

Allowed statuses: `not-reviewed`, `aligned`, `partial`, `gap`, `accepted-deviation`, `not-applicable`.

## Reference architecture and blueprint decisions

| ID | Official asset | Category | Applicability | Decision | Adaptations or deviations | Deployable source and version | Evidence |
|---|---|---|---|---|---|---|---|

Allowed decisions: `adopt`, `adapt`, `reference-only`, `reject`.

## Cross-provider normalization

Map comparable concerns only after completing provider-native reviews. Preserve provider terminology and document where apparently similar pillars differ in scope or intent.

## Findings and next gate

Summarize blockers, high-priority gaps, accepted deviations, evidence gaps, owners, and the conditions for the next architecture review.
