#!/usr/bin/env python3
"""List official framework, architecture, blueprint, and icon sources by cloud provider."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


REGISTRY = Path(__file__).resolve().parent.parent / "assets" / "official-provider-guidance.json"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("provider", choices=("azure", "aws", "gcp", "ibm", "all"))
    parser.add_argument("--json", action="store_true", dest="json_output")
    args = parser.parse_args()
    payload = json.loads(REGISTRY.read_text(encoding="utf-8"))
    providers = payload["providers"]
    selected = providers if args.provider == "all" else {args.provider: providers[args.provider]}
    if args.json_output:
        print(json.dumps({
            "last_verified": payload["last_verified"],
            "source_policy": payload["source_policy"],
            "providers": selected,
        }, indent=2, ensure_ascii=False))
        return 0
    print(f"Registry last verified: {payload['last_verified']}")
    print(f"Policy: {payload['source_policy']}")
    for provider_id, provider in selected.items():
        print(f"\n{provider['display_name']} ({provider_id})")
        print(f"  Well-Architected: {provider['well_architected']['url']}")
        print(f"  Architecture catalog: {provider['architecture_catalog']['url']}")
        print(f"  Foundation: {provider['foundation']['url']}")
        for blueprint in provider.get("deployable_blueprints", []):
            print(f"  Blueprint: {blueprint['name']} — {blueprint['url']}")
        print(f"  Diagram assets: {provider['diagram_assets']['url']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
