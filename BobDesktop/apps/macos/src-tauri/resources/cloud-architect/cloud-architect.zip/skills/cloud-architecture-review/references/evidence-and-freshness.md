# Evidence and freshness

## Evidence hierarchy

Prefer, in order:

1. user-provided system evidence, approved requirements, measurements, configurations, and test results;
2. official provider documentation, pricing, SLA, service quota, architecture, and security guidance;
3. authoritative standards and framework publications;
4. clearly identified secondary material when primary evidence is unavailable.

## Volatile claims

Reverify provider service names, feature availability, region support, limits, quotas, prices, discounts, SLAs, deprecations, icon packs, Well-Architected frameworks, lenses, perspectives, reference architectures, landing zones, blueprints, deployable assets, and implementation repositories during the task. Record retrieval date and affected claim.

Official architecture catalogs and registry files are discovery aids. A current official page, implementation guide, or repository is required to support a claim that a specific blueprint is maintained, deployable, compliant, supported, or applicable.

## Confidence

- Confirmed: directly supported by current evidence.
- Probable: supported indirectly but missing one material verification.
- Assumed: required for progress and explicitly stated.
- Unknown: insufficient evidence and potentially design-changing.

## Review behavior

Do not convert missing evidence into a negative finding automatically. Record the gap, explain its decision impact, and define the evidence required to close it. Never report a control, benchmark, failover, cost saving, or recovery target as achieved without evidence.
