# High-Level Design: [System or program]

Document status: Draft | Proposed | Approved
Version: [x.y]
Owners: [names or roles]
Reviewers: [names or roles]
Decision date: [date]

## Executive summary

State the business outcome, recommendation, material tradeoffs, cost or delivery implications, and decision required.

## Scope and audience

Define included and excluded systems, environments, teams, and lifecycle stages.

## Requirements and constraints

List functional scope, availability, latency, RTO, RPO, scale, security, compliance, residency, budget, delivery, and operating-model requirements. Identify source and confidence.

## Facts, assumptions, and open questions

Keep the three categories separate. Explain the architectural impact of unresolved assumptions.

## Current state

Describe relevant capabilities, pain points, dependencies, constraints, and evidence. Include a context or current-state diagram when useful.

## Target architecture

Explain the target state and include the smallest useful set of context, logical, deployment, network, security/data-flow, and sequence diagrams.

## Component inventory and interfaces

For each component, record ID, responsibility, service or technology, owner, deployment boundary, state, scaling, data, dependencies, and lifecycle.

## Architecture decisions

Summarize approved and proposed ADRs, alternatives, rationale, consequences, and evidence.

## Official framework and blueprint alignment

Identify the current provider-native Well-Architected framework, applicable lenses or perspectives, closest official reference architectures, relevant landing zones or foundations, and deployable blueprints considered. Summarize pillar status, gaps, accepted deviations, blueprint reuse decisions, evidence, owners, and remediation. Use [framework-alignment-template.md](framework-alignment-template.md) for a detailed scorecard.

## Security and compliance

Cover identity, trust boundaries, secrets, encryption, network controls, logging, supply chain, vulnerability management, auditability, data classification, retention, and regulatory obligations.

## Reliability and disaster recovery

Cover failure domains, degradation, dependency behavior, backups, restore, replication, failover, failback, RTO/RPO assumptions, and test evidence.

## Performance, scale, and cost

Show workload assumptions, capacity model, bottlenecks, autoscaling, quotas, cost drivers, ranges, budgets, and optimization options.

## Operations and observability

Define SLOs, telemetry, alerting, ownership, deployment health, configuration drift, incident response, runbooks, maintenance, and lifecycle.

## Migration and implementation

Describe prerequisites, waves, dependencies, data migration, validation, cutover, rollback, coexistence, and exit criteria.

## Risks and mitigations

Record likelihood, impact, mitigation, contingency, owner, due date, and residual risk.

## Acceptance criteria

Define measurable design, implementation, security, reliability, operational, migration, and documentation gates.

## Sources

List authoritative sources, retrieval dates, affected claims, and freshness assumptions.
