# Visual quality contract

## Composition

- Give each diagram one title, one scope, one abstraction level, and one primary story.
- Use a consistent left-to-right or top-to-bottom reading direction.
- Separate context, logical, deployment, network, data, and runtime concerns when density grows.
- Prefer several complementary views over one wall-sized diagram.
- For a master view, declare a fixed target such as 16:9, A3 landscape, or an explicit wall-sized canvas before placing nodes.
- A primary runtime story must occupy one uninterrupted left-to-right or top-to-bottom lane. Put observability, security, identity, and delivery in separate cross-cutting bands when they would otherwise disturb that lane.
- Reject accidental portrait towers and ultra-wide strips. If auto-layout cannot preserve a useful aspect ratio and stable group order after two iterations, split the view or switch to a deterministic fixed layout.

## Geometry

- Align nodes and boundaries to a consistent grid.
- Keep peer nodes the same size unless size encodes a documented meaning.
- Use consistent internal padding, boundary padding, node gaps, and label offsets.
- Use orthogonal connectors for cloud topology and flow diagrams.
- Keep edges behind nodes and away from text and icons.
- Minimize crossings, bends, and long return paths.
- Reserve connector gutters between boundaries and workload rows. Route secondary flows through those gutters.
- Do not allow unrelated connectors to overlap on the same segment. Parallel flows need visible separation at the delivery size.
- Keep at least one connector-width of clear space between a connector or edge label and adjacent node text.

## Labels

- Use concise service names and put explanatory detail in a document or tooltip.
- Label critical edges directly. Do not require readers to decode an oversized legend.
- Preserve adequate space for the longest label at the delivery size.
- Use a typography hierarchy with no text smaller than the target medium can reliably render.
- Measure containment after rendering: every label and subtitle must remain inside its owning card or boundary.
- Wrap full service names to a second line when required. Do not clip them, let them overflow, or replace meaningful text with ellipsis merely to make the render pass.
- For screen delivery, target an effective minimum of 12 px for supporting text and 14 px for primary labels at the exported preview size. If this cannot be met, reduce density or split the view.

## Semantics

- Show providers, organizations, accounts/projects/subscriptions, regions, zones, networks, clusters, namespaces, and trust boundaries only when relevant to the view.
- Pair line style and labels with color for synchronous, asynchronous, management, data, replication, and failover flows.
- Mark facts, proposals, options, risks, and unverified elements distinctly.

## Accessibility

- Maintain sufficient contrast in light and dark delivery contexts.
- Never encode meaning by color alone.
- Add SVG title and description when generating custom SVG.
- Preserve readable labels and logical order for screen-reader summaries where the target supports them.

## Failure conditions

Reject the diagram if any of these remain:

- edge through node, icon, label, or boundary title;
- unintended node, text, or boundary overlap;
- clipped or missing text or icon;
- ambiguous direction or unlabeled critical flow;
- inconsistent icon family or deprecated provider icon;
- mixed abstraction levels that obscure the story;
- contradiction with the component inventory or architecture model;
- unreadable result after embedding in the final document or slide.
- accidental aspect ratio that forces scrolling in only one direction and destroys the intended reading order;
- label or subtitle outside its card, clipped by a boundary, or shortened with an unexplained ellipsis;
- two unrelated connectors sharing a segment or a dense bundle whose individual destinations cannot be followed;
- auto-layout retained after two failed visual inspections when a fixed layout or split view would be clearer.

## Mandatory inspection record

For every delivered master diagram, record:

- target canvas and intended display size;
- reading direction and primary story;
- structural QA result;
- visual inspection at 100% and delivery size;
- any switch from auto-layout to fixed layout or any view split;
- confirmation that text containment, connector separation, official icons, and model reconciliation passed.
