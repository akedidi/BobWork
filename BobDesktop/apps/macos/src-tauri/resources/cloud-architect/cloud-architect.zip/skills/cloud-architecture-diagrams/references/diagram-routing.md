# Diagram routing

| Need | Preferred engine | Fallback | Primary output |
|---|---|---|---|
| Cloud or Kubernetes topology with icons | D2 + ELK | Graphviz | SVG + source |
| Network and trust zones | D2 + ELK | Graphviz | SVG + source |
| C4 views | D2 or Structurizr | Mermaid | SVG + source |
| Sequence | PlantUML or Mermaid | SVG/HTML | SVG + source |
| Workflow or activity | D2 + ELK or Mermaid | PlantUML | SVG + source |
| State machine | Mermaid or PlantUML | Graphviz | SVG + source |
| Formal UML | PlantUML | Mermaid | SVG + source |
| Presentation-native simple flow | PowerPoint shapes | Embedded SVG | PPTX |
| Interactive explainer | Accessible SVG/HTML | Static SVG | HTML + SVG |

## Selection rules

- Choose D2 plus ELK when automatic orthogonal layout and provider icons are the dominant needs.
- Choose Graphviz when a widely available deterministic renderer is required or D2 is absent.
- Choose Mermaid when direct Markdown portability matters and the graph is modest.
- Verify Mermaid Architecture syntax and registered icon packs before relying on provider icons.
- Choose PlantUML for formal UML semantics or detailed sequences.
- Generate a diagrams.net or equivalent editable handoff only when the user explicitly needs manual editing in that tool.

Never select an engine solely because it is familiar. Select it from layout, icon, semantic, editability, delivery-format, and runtime requirements.
