# Provider and platform review

## Source policy

For current capabilities, limits, prices, SLAs, service names, support status, frameworks, reference architectures, blueprints, and icon assets, consult official provider documentation during the task. Record the URL and retrieval date. Treat [official-provider-frameworks.md](official-provider-frameworks.md) and its JSON registry as navigation aids, not evidence of current applicability.

For each provider-specific design, complete the provider-native review before normalizing findings across clouds. Record `framework_alignment` entries for the official framework, selected workload guidance, closest reference architectures, relevant foundation or landing zone, and any blueprint considered for adoption.

## AWS

Use the current AWS Well-Architected Framework and applicable lenses. Search the AWS Architecture Center for workload examples and diagrams. Evaluate AWS Control Tower and, when relevant, Landing Zone Accelerator on AWS before designing a custom multi-account foundation. Model accounts, organizations, regions, availability zones, VPCs, subnets, route domains, endpoints, IAM boundaries, encryption keys, logging, backup, and service quotas. Use the current AWS Architecture Icons package for final provider-specific visuals.

## Azure

Use the current Azure Well-Architected Framework and applicable workload or service guidance. Search Azure Architecture Center for example workloads and reference architectures. Evaluate Cloud Adoption Framework landing zones and official platform or application landing-zone deployment options before designing a custom foundation. Model tenants, management groups, subscriptions, regions, availability zones, VNets, subnets, private endpoints, managed identities, policy, monitoring, backup, and recovery vaults. Use the current Azure Architecture Icons package and follow its usage rules.

## Google Cloud

Use the current Google Cloud Well-Architected Framework and applicable perspectives. Search the Cloud Architecture Center for reference architectures. Evaluate the enterprise foundations blueprint and relevant workload blueprints before designing a custom organization or application platform. Model organizations, folders, projects, regions, zones, VPCs, service perimeters, IAM, keys, logging, backup, and quotas. Use the current Google Cloud product icon library and distinguish current from legacy iconography.

## IBM Cloud

Use the current IBM Well-Architected Framework. Search the IBM Architecture Collection and IBM Cloud documentation for general, hybrid, industry, and regulated reference architectures. Evaluate IBM Cloud enterprise account guidance and official deployable architectures, including VPC or Red Hat OpenShift landing-zone variants, before designing a custom foundation. Model enterprises, account groups, accounts, regions, multizone regions, VPCs, subnets, transit, IAM, context-based restrictions, key management, logging, compliance, backup, and deployable-architecture ownership. Use official IBM Cloud Architecture Icons and Stencils.

## Kubernetes

Model clusters, control-plane ownership, node pools, namespaces, ingress and egress, workloads, services, policies, secrets, persistent storage, autoscaling, disruption budgets, observability, upgrades, and supply-chain controls. Show cloud-managed services such as EKS, AKS, or GKE separately from Kubernetes resources inside the cluster.

## Hybrid and multi-cloud

Make the reason for multiple environments explicit. Show identity federation, connectivity, DNS, data authority, replication, observability, governance, deployment control planes, operational ownership, and exit or portability assumptions. Do not claim portability merely because containers are used.
