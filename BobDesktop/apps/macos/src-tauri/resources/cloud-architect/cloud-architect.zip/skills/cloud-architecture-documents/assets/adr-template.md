# ADR-[ID]: [Decision title]

Status: Proposed | Accepted | Superseded | Rejected
Date: [date]
Owners: [names or roles]
Related requirements: [IDs]
Related risks: [IDs]

## Context

Explain the decision pressure, constraints, quality attributes, current state, and evidence.

## Decision drivers

List the criteria that distinguish viable alternatives.

## Considered options

Describe each viable option consistently. Include operational, security, reliability, cost, delivery, portability, and organizational consequences.

## Decision

State the selected option precisely, including scope and exceptions.

## Rationale

Explain why the selected option best satisfies the drivers and why alternatives were not selected.

## Consequences

Separate positive, negative, neutral, and follow-up consequences.

## Validation

Define evidence, prototype, benchmark, review, test, or operational signal required to confirm the decision.

## Revisit triggers

List conditions that should reopen the decision.

## Sources

Record authoritative sources and retrieval dates.
