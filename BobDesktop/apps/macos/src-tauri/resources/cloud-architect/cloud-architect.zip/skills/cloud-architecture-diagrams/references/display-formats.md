# Diagram display formats

Use one exact prompt directive when the user wants deterministic visual composition.

| Directive | Purpose | Required output |
| --- | --- | --- |
| `[diagram-format:executive-boxes]` | Clear screen or slide master | Fixed 1920×1080 landscape; aligned white cards; visible rounded borders; official icons; contained labels; lightly tinted bounded zones; connector gutters; left-to-right runtime story |
| `[diagram-format:technical-detailed]` | Complete engineering topology | `architecture-technical.svg` and `.png`; retain an executive master separately when the view is dense |
| `[diagram-format:auto]` | Let the platform route the view | Executive boxes for a dense master; automatic layout only for technical companions |

The selected profile is binding. Validate an executive master with `scripts/qa_professional_svg.py architecture.svg --master`. Split the model rather than shrinking text, weakening boundaries, or accepting crossed connector lanes.


## Orientation directives

- `[diagram-orientation:horizontal]`: 1920×1080, left-to-right; recommended for complex cloud blueprints and conversation previews.
- `[diagram-orientation:vertical]`: 1080×1920, top-to-bottom; intended for portrait documents.

Pass the same value to both `render_professional_svg.py --orientation` and `qa_professional_svg.py --master --orientation`.
