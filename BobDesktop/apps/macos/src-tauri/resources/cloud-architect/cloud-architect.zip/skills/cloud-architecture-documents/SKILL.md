---
name: cloud-architecture-documents
description: Create polished, technically coherent cloud architecture deliverables including HLD, LLD, ADR, executive briefs, architecture review packs, migration plans, disaster-recovery plans, runbooks, DOCX, PDF, and PowerPoint. Use when architecture decisions or diagrams must become professional audience-ready documents with render-and-inspect quality assurance.
---

# Cloud Architecture Documents

Turn the architecture model and reviewed diagrams into decision-ready and implementation-ready artifacts. Keep facts, assumptions, decisions, risks, diagrams, component names, and requirements consistent across every format.

## Route by audience and format

- Use an executive brief or presentation for sponsors, funding, and decision boards.
- Use an HLD for cross-team agreement on scope, qualities, patterns, boundaries, and decisions.
- Use an LLD for implementation details, configuration, interfaces, deployment, and operations.
- Use ADRs for material decisions and alternatives.
- Use a migration plan for waves, dependencies, cutover, validation, rollback, and ownership.
- Use a DR plan or runbook for detection, authority, recovery actions, validation, failback, and evidence.

Read [references/format-routing.md](references/format-routing.md) and [references/document-contract.md](references/document-contract.md) before authoring.

## Source-of-truth contract

1. Start from the architecture model and approved decisions.
2. Preserve stable component, flow, decision, risk, and evidence identifiers.
3. Insert only diagrams that passed the diagram render and inspection gate.
4. Treat provider capabilities, limits, prices, SLAs, and recommendations as time-sensitive evidence.
5. Preserve provider-native `framework_alignment`, reference-architecture comparisons, blueprint reuse decisions, gaps, deviations, and retrieval dates in HLD and review packs.
6. Keep executive summaries concise while retaining material caveats and decision consequences.
7. Do not use tables to package ordinary prose. Use tables for repeated comparable records.

## Format integration

- For DOCX, load and follow `$documents`. Choose a suitable design preset, use real Word styles and numbering, render every page to PNG, inspect every page, fix defects, and rerender.
- For PDF, load and follow `$pdf`. Render every final page to PNG and inspect spacing, typography, diagrams, tables, headers, footers, and glyphs.
- For PowerPoint, load and follow `$Presentations`. Use the available artifact tooling, render every slide, run overflow checks, inspect full-size slides, and fix connector or layout defects.
- For Markdown, preserve heading hierarchy, source links, editable diagram sources, and stable cross-references.

When a requested companion skill is unavailable, use the closest supported local format and state the limitation. Never claim a document passed visual QA when it was not rendered and inspected.

## Authoring sequence

1. Confirm audience, decision, delivery format, page or slide budget, language, and template or brand constraints.
2. Select the smallest appropriate template from `assets/`.
3. Build the narrative: context, decision, evidence, recommendation, consequences, implementation, operations, risks, and next actions.
4. Place diagrams where they answer a concrete question. Add captions and cross-references.
5. Generate the requested format using its specialized skill.
6. Render, inspect, correct, and rerender.
7. Cross-check the final artifact against the model and review scorecard.

## Template routing

- [assets/hld-template.md](assets/hld-template.md): high-level design or architecture dossier.
- [assets/adr-template.md](assets/adr-template.md): durable architecture decision.
- [assets/migration-and-dr-template.md](assets/migration-and-dr-template.md): migration, cutover, rollback, recovery, and test plan.
- [assets/executive-brief-template.md](assets/executive-brief-template.md): concise sponsor or architecture-board communication.

Adapt templates to the engagement. Remove unused sections instead of filling them with generic text.

## Acceptance gate

Reject the document if it contains contradictory component names, unsupported claims, arbitrary NFR targets, stale provider terminology, unresolved placeholders presented as facts, illegible diagrams, broken captions, poor page or slide breaks, clipped content, inconsistent formatting, missing owners, or risks without mitigations.
