# [Architecture decision or program]

## Decision required

State the decision, owner, and deadline in one concise paragraph.

## Recommendation

State the target outcome, selected approach, and why it is preferred.

## Business and risk impact

Summarize value, cost range, delivery implications, major risks, controls, and consequences of delay or inaction.

## Architecture at a glance

Include one context or target-state diagram that remains legible at presentation scale.

## Alternatives considered

Summarize viable alternatives and the decisive tradeoffs.

## Delivery path

Show phases, key dependencies, decision gates, and accountable owners.

## Open decisions and requested actions

List only items requiring sponsor or board action.
