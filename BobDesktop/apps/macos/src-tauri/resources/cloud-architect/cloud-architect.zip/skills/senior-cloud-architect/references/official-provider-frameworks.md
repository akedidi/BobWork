# Official provider frameworks and architecture assets

Use this reference to route provider-specific architecture work. The machine-readable registry is [../assets/official-provider-guidance.json](../assets/official-provider-guidance.json).

## Mandatory provider guidance workflow

1. Identify every target provider in the architecture model.
2. Load the current official Well-Architected framework for each provider.
3. Select applicable workload lenses, perspectives, service guides, industry guidance, and regulatory overlays from official sources.
4. Search the provider's official architecture catalog for the closest workload examples and reference architectures.
5. Search official landing-zone, foundation, accelerator, solution, or deployable-architecture catalogs for reusable platform blueprints.
6. Classify each source as one of:
   - `framework`: quality principles and review questions;
   - `reference-architecture`: descriptive pattern or example, not automatically deployable;
   - `blueprint`: prescriptive foundation or workload pattern, possibly accompanied by IaC;
   - `implementation`: deployable code, module, template, accelerator, or managed landing-zone service;
   - `diagram-assets`: official icons, stencils, or editable diagram assets.
7. Record sources, retrieval dates, applicability, deviations, and freshness in `framework_alignment` and `evidence`.
8. Use official guidance as evidence and a review baseline, not as a substitute for workload requirements or engineering judgment.

## Cross-provider routing

| Provider | Well-Architected baseline | Architecture examples | Foundation / landing zone | Deployable patterns | Diagram assets |
|---|---|---|---|---|---|
| Azure | Azure Well-Architected Framework | Azure Architecture Center | Azure landing zones / Cloud Adoption Framework | Platform and application landing-zone deployment options, accelerators, AVM/Bicep/Terraform guidance | Azure Architecture Icons |
| AWS | AWS Well-Architected Framework and applicable lenses | AWS Architecture Center | AWS Control Tower landing zone | Landing Zone Accelerator on AWS and AWS Solutions implementation guides | AWS Architecture Icons |
| Google Cloud | Google Cloud Well-Architected Framework and applicable perspectives | Cloud Architecture Center | Enterprise foundations blueprint | Enterprise foundations and enterprise application blueprints with linked Terraform assets | Google Cloud product icons |
| IBM Cloud | IBM Well-Architected Framework | IBM Architecture Collection and IBM Cloud reference architectures | IBM Cloud enterprise architecture | IBM Cloud deployable architectures and VPC/OpenShift landing zones | IBM Cloud Architecture Icons and Stencils |

The names above are navigation labels. Reverify the current official pages and status during the task; do not treat this file as evidence of feature availability, support, compliance, or deployability.

## Alignment record

For each applicable framework or blueprint, record:

- stable ID, provider, official name, category, URL, and retrieval date;
- applicability and selected workload lens or perspective;
- pillar or design area;
- status: `not-reviewed`, `aligned`, `partial`, `gap`, `accepted-deviation`, or `not-applicable`;
- architecture components, flows, decisions, risks, and evidence that support the status;
- gap, consequence, remediation, owner, and acceptance evidence;
- blueprint reuse decision: `adopt`, `adapt`, `reference-only`, or `reject`, with rationale;
- blueprint implementation type and source repository when deployable assets exist.

Never report a workload as "Well-Architected" from checklist completion alone. Report assessed scope, evidence coverage, unresolved gaps, accepted deviations, and review date.

## Multi-cloud behavior

- Evaluate each provider against its own official framework first.
- Create a normalized cross-cloud view only after provider-native reviews are complete.
- Map similar pillars without claiming equivalence. Preserve provider-specific semantics, scopes, and review questions.
- Review shared identity, connectivity, data authority, observability, governance, operations, DR, portability, and exit assumptions across providers.
- Do not select services by superficial one-to-one equivalence. Compare responsibilities, failure behavior, security model, operational burden, regional availability, and cost model.

## Blueprint reuse guardrails

- Verify that the blueprint is current, officially maintained, applicable to the target region and cloud partition, and compatible with the workload's requirements.
- Distinguish diagrams from deployable artifacts. A published diagram is not proof that an implementation is production-ready.
- Inspect linked IaC, release status, versioning, dependencies, destructive behavior, telemetry, cost, and customization boundaries before recommending adoption.
- Record every material deviation from the official blueprint as an ADR or finding.
- Never copy a reference architecture blindly; preserve its design intent while adapting it to explicit requirements.
