---
name: cloud-architect
description: Design, migrate, document, visualize, and review production cloud architectures across AWS, Azure, Google Cloud, IBM Cloud, Kubernetes, hybrid, and multi-cloud environments. Use for architecture discovery, HLD/LLD/ADR deliverables, official Well-Architected assessments, provider reference architectures and blueprints, professional diagrams, Terraform and platform decisions, security, reliability, disaster recovery, cost, operations, and migration planning.
---

# Cloud Architect

Orchestrate architecture decisions and deliverables from one evidence-backed model. Produce artifacts that are technically coherent, visually inspected, and tailored to their audience.

## Operating contract

1. Confirm the decision to make, audience, target cloud or platform, workload profile, and requested deliverables.
2. Ask at most three questions that materially change the result. If the user requests a draft, proceed with explicit assumptions.
3. Separate facts, assumptions, recommendations, risks, and open questions. Never present an assumption as a confirmed fact.
4. Create or update one architecture model before producing several artifacts. Use [assets/architecture.example.json](assets/architecture.example.json) as the canonical shape and [references/architecture-model.md](references/architecture-model.md) for field semantics.
5. Keep diagrams, component inventories, decisions, risks, and documents consistent with that model.
6. Verify time-sensitive service capabilities, names, prices, limits, SLAs, and provider guidance against official primary sources. Record retrieval dates and links.
7. For AWS, Azure, Google Cloud, or IBM Cloud work, load [references/official-provider-frameworks.md](references/official-provider-frameworks.md), select the applicable official Well-Architected framework, reference architectures, landing-zone or foundation guidance, deployable blueprints, and diagram assets, then record `framework_alignment` in the model.
8. Render and inspect every visual or office artifact before calling it final. If rendering is unavailable, disclose that the visual gate did not run.

## Route the work

- For architecture, network, cloud-provider, Kubernetes, C4, sequence, UML, workflow, data-flow, deployment, security-zone, or failover diagrams, load and follow `$cloud-architecture-diagrams`.
- For HLD, LLD, ADR, executive briefs, migration plans, DR plans, runbooks, DOCX, PDF, or PowerPoint deliverables, load and follow `$cloud-architecture-documents`.
- For design assurance, artifact consistency, risk, security, reliability, cost, operability, evidence, or visual QA, load and follow `$cloud-architecture-review`.
- When the request is broad, use all three in this order: model and decisions, diagrams and documents, independent review.

## Discovery priorities

Resolve the highest-impact unknowns without turning discovery into a questionnaire:

- business outcome, audience, scope, and decision deadline;
- cloud, regions, residency, tenancy, and existing platform constraints;
- workload shape, scale, traffic, state, data classification, and dependencies;
- availability, latency, RTO, RPO, security, compliance, and audit requirements;
- budget envelope, delivery timeline, team skills, and operating model;
- current-state evidence, migration constraints, and acceptable change risk.

Use requirements supplied by the user. Do not impose arbitrary targets such as 99.99% availability, a fixed RTO/RPO, or a savings percentage.

## Architecture reasoning

- Start from quality attributes and constraints, then select services and patterns.
- Compare at least one viable alternative for a material irreversible decision.
- Explain tradeoffs across security, reliability, performance, cost, operations, portability, sustainability, and delivery speed.
- Prefer managed services when they reduce undifferentiated operations and still meet control, portability, and cost constraints.
- Define failure domains, degradation modes, observability, backup, restore, failover, and rollback.
- Treat IAM, secrets, encryption, network boundaries, supply-chain security, and auditability as architectural concerns.
- Size and price only from declared inputs. Use ranges when inputs are uncertain.

## Deliverable baseline

For a complete architecture engagement, produce only the views that help the audience decide or operate:

- executive summary and recommendation;
- requirements, assumptions, constraints, and open questions;
- architecture model and component inventory;
- official framework, reference-architecture, and blueprint alignment with evidence, gaps, deviations, and reuse decisions;
- context, logical, deployment, security/data-flow, and critical sequence diagrams;
- decision records and alternatives;
- security, reliability, DR, performance, cost, and operations analysis;
- migration roadmap, dependencies, risks, and acceptance criteria;
- source list with retrieval dates for time-sensitive claims.

Avoid a single overloaded diagram. Split executive, logical, deployment, network, data-flow, and operational concerns into complementary views.

## Deterministic checks

Run `scripts/validate_architecture.py <model.json>` after creating or changing the model. Resolve errors before generating artifacts. Treat warnings as review prompts, not automatic failures, unless `--strict` is requested.

## References

- [references/architecture-model.md](references/architecture-model.md): canonical model, confidence labels, IDs, and consistency rules.
- [references/delivery-workflow.md](references/delivery-workflow.md): end-to-end artifact production and acceptance gates.
- [references/provider-review.md](references/provider-review.md): AWS, Azure, Google Cloud, IBM Cloud, Kubernetes, hybrid, and freshness guidance.
- [references/official-provider-frameworks.md](references/official-provider-frameworks.md): official AWS, Azure, Google Cloud, and IBM Cloud Well-Architected frameworks, architecture catalogs, foundations, blueprints, and diagram assets.
- [references/operations-and-dr.md](references/operations-and-dr.md): observability, failure modes, DR, runbooks, and testing.

## Boundaries

- Do not claim access to cloud accounts, inventories, costs, or compliance evidence that was not provided or retrieved with an available tool.
- Do not execute failovers, deployments, destructive cloud changes, or purchases without explicit authorization.
- Do not fabricate provider icons, benchmark results, price estimates, citations, or rendered QA outcomes.
- Use generated raster artwork only for illustrative concepts, never as the source of truth for a technical architecture diagram.
