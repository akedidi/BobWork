---
name: cloud-architecture-review
description: Review cloud architecture models, diagrams, HLD/LLD/ADR documents, migration and disaster-recovery plans for consistency, evidence, security, reliability, performance, cost, operations, delivery risk, and visual quality. Use for design assurance, Well-Architected assessment, architecture review boards, remediation plans, or final artifact QA.
---

# Cloud Architecture Review

Perform an evidence-backed review without inventing certainty. Separate verified findings from assumptions and recommendations. Review technical design and delivered artifacts as one system.

## Review sequence

1. Confirm review scope, decision stage, required framework, available evidence, and risk tolerance.
2. For AWS, Azure, Google Cloud, or IBM Cloud, load the provider registry from `$cloud-architect`, reverify the official Well-Architected framework, architecture catalog, foundation or landing-zone guidance, and applicable blueprints, then confirm the selected review baseline.
3. Validate the architecture model and identify missing or inconsistent inputs.
4. Trace requirements to components, flows, decisions, tests, and acceptance criteria.
5. Review each applicable provider-native pillar, lens or perspective; then assess reference-architecture and blueprint reuse or deviation.
6. Review security, reliability, performance, cost, operations, sustainability, migration, and organizational fit.
7. Review diagram and document quality after rendering.
8. Rank findings by impact, likelihood, urgency, and remediation dependency.
9. Distinguish blocker, high, medium, low, observation, and accepted risk.

Read [references/review-checklist.md](references/review-checklist.md) and [references/evidence-and-freshness.md](references/evidence-and-freshness.md).

## Finding contract

For every finding, record:

- stable ID and severity;
- affected requirement, component, flow, decision, or artifact;
- verified observation and evidence;
- consequence or failure scenario;
- recommendation and viable alternative when relevant;
- owner, priority, dependency, and acceptance evidence;
- confidence and unresolved questions.

Do not assign a precise severity from intuition alone. Explain the impact and likelihood basis.

## Architecture checks

- Requirements are explicit, sourced, testable, and not arbitrary plugin defaults.
- Failure domains, dependency behavior, degraded modes, backup, restore, failover, and rollback are designed.
- Identity, trust boundaries, secrets, encryption, network policy, audit, and data lifecycle are coherent.
- Capacity, quotas, bottlenecks, performance assumptions, and cost drivers are visible.
- Observability, ownership, incident response, change safety, and lifecycle are operable.
- Provider services and guidance are current and supported by official evidence.
- Provider-native Well-Architected pillars are assessed with evidence, gaps, accepted deviations, owners, and remediation; cross-cloud mappings do not erase provider-specific semantics.
- The closest official reference architectures and blueprints were considered, and every adopt, adapt, reference-only, or reject decision is documented.
- Migration sequencing, coexistence, data validation, cutover, rollback, and exit criteria are credible.

## Artifact consistency

- Every diagram component maps to the inventory or is explicitly a visual abstraction.
- Every critical edge maps to a relationship with direction and metadata.
- Documents and diagrams use the same names, boundaries, requirements, decisions, and risks.
- Executive summaries retain material caveats and do not overstate validation.
- ADR status and target architecture agree.
- Acceptance criteria correspond to the stated risks and requirements.

## Visual and document gate

Reject final status when diagrams, pages, or slides have not been rendered and inspected. Fail for unintended overlap, clipping, edge-through-node routing, missing icons, unreadable labels, inconsistent boundaries, broken tables, awkward page breaks, overflow, stale placeholders, or contradictions.

## Output

Lead with the decision and blockers. Provide a provider-native pillar scorecard, blueprint reuse decisions, prioritized remediation plan, accepted risks, evidence gaps, and the next review gate. Avoid generic checklist prose when no artifact-specific evidence supports it. Never declare an architecture "Well-Architected" without stating the assessed scope, evidence coverage, gaps, deviations, and review date.
