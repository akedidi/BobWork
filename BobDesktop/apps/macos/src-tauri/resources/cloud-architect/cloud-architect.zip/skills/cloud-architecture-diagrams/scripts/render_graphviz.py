#!/usr/bin/env python3
"""Generate DOT and optionally render a professional SVG topology."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


def load(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        payload = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise RuntimeError("YAML input requires PyYAML; use JSON or install PyYAML") from exc
        payload = yaml.safe_load(text)
    return payload["architecture"]


def q(value: Any) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def node_line(component: dict[str, Any]) -> str:
    attrs = {
        "label": component.get("label", component["id"]),
        "tooltip": component.get("description", component.get("label", component["id"])),
    }
    icon = component.get("icon")
    if icon and Path(icon).is_file():
        attrs.update({"image": str(Path(icon).resolve()), "imagescale": "true", "imagepos": "tc", "labelloc": "b"})
    rendered = ", ".join(f"{key}={q(value)}" for key, value in attrs.items())
    return f"    {q(component['id'])} [{rendered}];"


def build_dot(architecture: dict[str, Any], direction: str) -> str:
    components = architecture.get("components", [])
    boundaries = architecture.get("boundaries", [])
    relationships = architecture.get("relationships", [])
    by_boundary: dict[Any, list[dict[str, Any]]] = {}
    for component in components:
        by_boundary.setdefault(component.get("boundary"), []).append(component)

    lines = [
        "digraph architecture {",
        f"  graph [rankdir={direction}, bgcolor=\"#FFFFFF\", compound=true, newrank=true, splines=ortho, nodesep=0.55, ranksep=0.85, pad=0.45, fontname=\"Arial\", fontcolor=\"#0F172A\", fontsize=12, labelloc=t, label={q(architecture.get('name', 'Architecture'))}];",
        "  node [shape=box, style=\"rounded,filled\", fillcolor=\"#FFFFFF\", color=\"#475569\", fontcolor=\"#0F172A\", penwidth=1.2, fontname=\"Arial\", fontsize=11, margin=\"0.18,0.12\"];",
        "  edge [color=\"#475569\", penwidth=1.3, arrowsize=0.75, fontname=\"Arial\", fontsize=9, fontcolor=\"#334155\"];",
    ]

    for boundary in boundaries:
        boundary_id = boundary["id"]
        members = by_boundary.get(boundary_id, [])
        if not members:
            continue
        lines.extend([
            f"  subgraph {q('cluster_' + boundary_id)} {{",
            f"    label={q(boundary.get('label', boundary_id))};",
            "    color=\"#94A3B8\"; fillcolor=\"#F8FAFC\"; style=\"rounded,filled\"; penwidth=1.1; fontname=\"Arial\"; fontsize=11; margin=38;",
        ])
        lines.extend(node_line(component) for component in members)
        lines.append("  }")

    for component in by_boundary.get(None, []):
        lines.append(node_line(component).lstrip())

    for relationship in relationships:
        label_parts = [relationship.get("label", "")]
        protocol = relationship.get("protocol")
        port = relationship.get("port")
        if protocol and protocol not in label_parts[0]:
            label_parts.append(str(protocol))
        if port:
            label_parts.append(str(port))
        label = " | ".join(part for part in label_parts if part)
        lines.append(
            f"  {q(relationship['from'])} -> {q(relationship['to'])} "
            f"[taillabel={q(label)}, labeldistance=2.0, labelangle=-25];"
        )
    lines.append("}")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--dot", type=Path, required=True)
    parser.add_argument("--svg", type=Path)
    parser.add_argument("--direction", choices=("LR", "TB"), default="LR")
    args = parser.parse_args()

    architecture = load(args.model)
    args.dot.parent.mkdir(parents=True, exist_ok=True)
    args.dot.write_text(build_dot(architecture, args.direction), encoding="utf-8")
    print(args.dot)

    if args.svg:
        dot = shutil.which("dot")
        if not dot:
            raise RuntimeError("Graphviz 'dot' is unavailable; DOT source was generated but SVG was not rendered")
        args.svg.parent.mkdir(parents=True, exist_ok=True)
        completed = subprocess.run([dot, "-Tsvg", str(args.dot), "-o", str(args.svg)], check=False, text=True, capture_output=True)
        if completed.returncode:
            raise RuntimeError(completed.stderr.strip() or "Graphviz rendering failed")
        print(args.svg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
