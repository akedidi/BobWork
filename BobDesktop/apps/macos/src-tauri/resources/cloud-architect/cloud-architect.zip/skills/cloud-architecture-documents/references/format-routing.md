# Format routing

| Audience or purpose | Primary artifact | Supporting artifacts |
|---|---|---|
| Executive sponsor | Executive brief or PPTX | Context and target-state diagrams |
| Architecture review board | HLD and ADR set | Review scorecard and evidence list |
| Platform and application teams | HLD plus LLD | Deployment, network, data-flow, and sequence diagrams |
| Security and compliance | Security architecture section | Trust-zone and data-flow diagrams, control matrix |
| Operations and SRE | Operations and DR plan | Failure, observability, failover, and runbook views |
| Migration program | Migration plan | Dependency map, waves, cutover workflow, rollback plan |

## Format rules

- Use Markdown as an editable intermediate or repository-native artifact.
- Use DOCX when reviewers need Word workflows, comments, or formal distribution.
- Use PDF for stable publication after the source artifact passes visual QA.
- Use PPTX for live decision-making and executive communication, not as the only technical specification.
- Deliver editable diagram sources with the document unless the user requests only the publication format.
