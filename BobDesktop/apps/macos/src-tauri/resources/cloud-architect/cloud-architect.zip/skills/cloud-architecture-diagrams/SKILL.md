---
name: cloud-architecture-diagrams
description: Create and quality-assure professional cloud, Kubernetes, C4, network, security-zone, data-flow, deployment, workflow, sequence, state, failover, and UML diagrams with clean routing, official provider icons, editable sources, vector exports, and mandatory render-inspect-iterate QA. Use whenever an architecture request needs technical visuals or existing diagrams need improvement.
---

# Cloud Architecture Diagrams

Produce precise technical diagrams, not decorative architecture artwork. Preserve the architecture model as the source of truth and optimize each view for one audience and one decision.

## Required workflow

1. Read the architecture model or create the minimum model needed for the requested view.
2. Select a diagram type and engine using [references/diagram-routing.md](references/diagram-routing.md).
3. Apply [references/visual-quality-contract.md](references/visual-quality-contract.md) before rendering.
4. Use current official provider assets according to [references/icon-governance.md](references/icon-governance.md).
5. Generate an editable source and a vector SVG. Add PNG only when a raster format is required.
6. Declare the target canvas, delivery size, reading direction, minimum effective font size, and whether the output is screen-sized or explicitly wall-sized.
7. Render the source, inspect the full-size image and delivery-size raster, correct defects, and rerender until the quality gate passes.
8. Reconcile visible components and flows with the architecture model.

Never call raw diagram source final without a successful render and visual inspection. If no compatible renderer is available, return the editable source, label the render gate as not run, and do not claim visual perfection.

Reject an auto-layout result even when it is structurally valid if it produces a long vertical stack, an excessively wide strip, unstable group ordering, overlapping connector lanes, or labels that escape their cards. After two failed auto-layout iterations, split the view or switch to a deterministic fixed layout instead of continuing to tune rank hints.

## Engine selection

- Prefer D2 with ELK for cloud-provider, Kubernetes, network, deployment, security-zone, and complex workflow diagrams with orthogonal routing and icon assets.
- Use Graphviz as the deterministic fallback for complex topologies when D2 is unavailable. Generate DOT with `scripts/render_graphviz.py` and render SVG through `dot`.
- Use Mermaid for compact in-conversation flowcharts, sequences, states, journeys, and architecture views only when the required Mermaid version and icon packs are available.
- Use PlantUML for formal UML, detailed sequence, component, deployment, and activity diagrams when a PlantUML renderer is available.
- Use native PowerPoint shapes only for simple slide-native diagrams. Create connectors before nodes so edges remain behind objects.
- Use an interactive SVG or HTML view only when exploration, filtering, animation, or step-through behavior materially improves understanding.
- Use a deterministic fixed-layout SVG when a curated executive or deployment master view must combine provider services, Kubernetes resources, and cross-cutting concerns on one landscape canvas and automatic layout cannot preserve the intended reading order.

Do not use raster image generation for precise topology, labels, ports, protocols, or technical relationships.

## View selection

Choose the smallest useful set:

- C4 Context for system scope and external actors.
- C4 Container or logical view for responsibilities and dependencies.
- Cloud deployment view for providers, accounts, regions, zones, networks, and managed services.
- Kubernetes view for clusters, namespaces, workloads, services, policy, and storage.
- Network and trust-zone view for routing, ingress, egress, inspection, and private connectivity.
- Data-flow view for classification, encryption, authority, replication, and retention.
- Sequence diagram for critical runtime, failure, recovery, or authentication paths.
- Workflow or activity diagram for delivery, operations, approval, migration, or incident flows.
- DR topology and timeline for detection, failover, validation, and failback.

Split a view when it mixes more than two abstraction levels, has several unrelated stories, or cannot remain readable at its intended display size.

## Visual contract

- Use one reading direction per view.
- Prefer orthogonal connectors for topology and workflow diagrams.
- Prevent edges from crossing nodes, labels, icons, or boundary titles.
- Minimize crossings and bends; use junctions only when they clarify a shared path.
- Keep icon, label, node, and boundary spacing consistent.
- Label important flows with protocol, port, encryption, event, or data classification.
- Use color for stable semantics and pair it with text, line style, shape, or icon.
- Show title, scope, legend when needed, version, and status outside the technical canvas when the target format supports it.
- Distinguish current, target, optional, external, failed, and unverified elements without relying on color alone.
- Keep provider services inside explicit provider and deployment boundaries.
- Wrap labels inside their cards and preserve full official service names. Do not use clipping, overflow, or ellipsis to hide a layout defect.
- Reserve explicit connector lanes between rows or columns. Parallel flows must have visible separation; two unrelated flows must not share the same segment.
- Keep secondary security, delivery, and telemetry flows out of the primary runtime lane. Move them to a cross-cutting band or a dedicated view.

## Provider and Kubernetes icons

- Use official AWS, Azure, Google Cloud, IBM Cloud, Kubernetes, or CNCF SVG assets when the diagram is provider-specific.
- Keep the provider's service name next to the icon.
- Do not rotate, crop, recolor, stretch, or repurpose official product icons.
- Record the source URL, retrieval date, and asset version or checksum.
- Do not mix legacy and current icon systems in one diagram.
- Use a neutral generic icon when an official service icon is unavailable; never fabricate a provider icon.

## Deterministic helpers

- `scripts/generate_d2.py <model> --output architecture.d2`: generate an editable D2 topology source.
- `scripts/render_graphviz.py <model> --dot architecture.dot --svg architecture.svg`: generate and render the Graphviz fallback.
- `scripts/qa_svg.py <svg> --model <model>`: verify SVG structure and expected node/edge counts before visual inspection.

Use [assets/reference-architecture.json](assets/reference-architecture.json) for a smoke test and [assets/diagram-style.json](assets/diagram-style.json) for stable visual tokens.

## Render and inspection gate

Inspect the output at 100% and at its delivery size. Fail the gate for any unintended overlap, clipping, truncated or escaped label, unreadable text, missing icon, ambiguous arrow direction, connector through a node, shared unrelated connector segment, inconsistent boundary, excessive crossing, broken glyph, extreme unintended aspect ratio, or contradiction with the model. Correct the source and rerender.

Run `scripts/qa_svg.py` before visual sign-off. Structural QA does not replace inspection: use the raster preview to verify text containment, connector separation, group order, and effective font size. Record in the review whether the view is screen-sized or wall-sized and which defects were corrected between passes.

For office documents and slides, inspect the final embedded rendering again because scaling and conversion can introduce new defects.
